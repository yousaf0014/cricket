@extends('layouts.customer_panel')
@section('content')
<!-- Main content -->
<section class="content">
    <div class="row">
        @foreach ($itemData as $data)
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3>{{ $data->purchase_price }}</h3>
                    <p>{{ $data->description }}</p>
                </div>
                <div class="icon">
                    @if (!empty($data->img))
                    <img src='{{url("public/uploads/itemPic/$data->img")}}' alt="" width="50" height="50">
                    @else
                    <img src='{{url("public/uploads/default-image.png")}}' alt="" width="50" height="50">
                    @endif
                </div>
                <a href="{{ route('customer.order.cart', ['id' => $data->item_id ]) }}" class="small-box-footer">Add To Cart <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        @endforeach
    </div>
</section>
@endsection
@section('js')
@endsection