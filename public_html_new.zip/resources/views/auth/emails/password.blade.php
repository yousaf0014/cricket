
Click here to reset your password: <a href="{{ $link = url('password/resets',$data['token'])}}"> {{ $link }} </a>
