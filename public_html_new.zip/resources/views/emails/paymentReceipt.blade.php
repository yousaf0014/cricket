@include('emails.livery.html-header')
<?=$content?>
@include('emails.livery.html-footer')
