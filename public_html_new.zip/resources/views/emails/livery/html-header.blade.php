<!DOCTYPE html>
<html>
    <head>
        <title>{{ $subject }}</title>
    </head>
    <body>