<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

      <div class="box box-default">
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">
             <div class="top-bar-title padding-bottom"><?php echo e(trans('message.extra_text.payment')); ?></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Default box -->
    <div class="row">
        <div class="col-md-8 right-padding-col8">
            <div class="box box-default">
              <div class="box-body">
                    <div class="btn-group pull-right">
                      <button title="Email" type="button" class="btn btn-default btn-flat" data-toggle="modal" data-target="#emailReceipt"><?php echo e(trans('message.extra_text.email')); ?></button>
                      <a target="_blank" href="<?php echo e(URL::to('/')); ?>/payment/print-receipt/<?php echo e($paymentInfo->id); ?>" title="Print" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.print')); ?></a>
                      <a target="_blank" href="<?php echo e(URL::to('/')); ?>/payment/create-receipt/<?php echo e($paymentInfo->id); ?>" title="PDF" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.pdf')); ?></a>
                       <?php if(!empty(Session::get('payment_delete'))): ?>
                      <form method="POST" action="<?php echo e(url("payment/delete")); ?>" accept-charset="UTF-8" style="display:inline">
                          <?php echo csrf_field(); ?>

                          <input type="hidden" name="id" value="<?php echo e($paymentInfo->id); ?>">
                          <button class="btn btn-default btn-flat delete-btn" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.invoice.delete_payment_header')); ?>" data-message="<?php echo e(trans('message.invoice.delete_payment')); ?>">
                            <?php echo e(trans('message.extra_text.delete')); ?>

                          </button>
                      </form>
                      <?php endif; ?>
                    </div>
              </div>

              <div class="box-body">
                <div class="row">
                  
                  <div class="col-md-4">
                    <strong><?php echo e(Session::get('company_name')); ?></strong>
                    <h5 class=""><?php echo e(Session::get('company_street')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_city')); ?>, <?php echo e(Session::get('company_state')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_country_id')); ?>, <?php echo e(Session::get('company_zipCode')); ?></h5>
                  </div>                 

                  <div class="col-md-4">
                    <strong><?php echo e(!empty($paymentInfo->name) ? $paymentInfo->name : ''); ?></strong>
                    <h5><?php echo e(!empty($paymentInfo->billing_street) ? $paymentInfo->billing_street : ''); ?></h5>
                    <h5><?php echo e(!empty($paymentInfo->billing_city) ? $paymentInfo->billing_city : ''); ?><?php echo e(!empty($paymentInfo->billing_state) ? ', '.$paymentInfo->billing_state : ''); ?></h5>
                    <h5><?php echo e(!empty($paymentInfo->billing_country_id) ? $paymentInfo->billing_country_id : ''); ?><?php echo e(!empty($paymentInfo->billing_zip_code) ? ', '.$paymentInfo->billing_zip_code: ''); ?></h5> 
                  </div>

                </div>
                <h3 class="text-center">PAYMENT RECEIPT</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <h5><?php echo e(trans('message.invoice.payment_date')); ?> : <?php echo e(formatDate($paymentInfo->payment_date)); ?></h5>
                      <h5><?php echo e(trans('message.invoice.payment_on')); ?> : <?php echo e($paymentInfo->payment_method); ?></h5>
                      <div class="well well-lg label-primary text-center"><strong><?php echo e(trans('message.invoice.total_amount')); ?><br/><?php echo e(Session::get('currency_symbol').number_format($paymentInfo->amount,2,'.',',')); ?></strong></div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="table-responsive">
                          <table class="table table-bordered">
                            <tbody>
                              <tr class="tbl_header_color dynamicRows">
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.order_no')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.invoice_no')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.invoice_date')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.invoice_amount')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.paid_amount')); ?></th>
                              </tr>
                              <tr>
                                <td width="20%" class="text-center"><?php echo e($paymentInfo->order_reference); ?></td>
                                <td width="20%" class="text-center"><?php echo e($paymentInfo->invoice_reference); ?></td>
                                <td width="20%" class="text-center"><?php echo e(formatDate($paymentInfo->invoice_date)); ?></td>
                                <td width="20%" class="text-center"><?php echo e(Session::get('currency_symbol').number_format($paymentInfo->invoice_amount,2,'.',',')); ?></td>
                                <td width="20%" class="text-center"><?php echo e(Session::get('currency_symbol').number_format($paymentInfo->amount,2,'.',',')); ?></td>
                              </tr>
                            </tbody>
                          </table>
                      </div>
                      </div>
                  </div>
              </div>

            </div>
        </div>
        <!--Modal start-->
        <div id="emailReceipt" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <form id="sendPaymentReceipt" method="POST" action="<?php echo e(url('payment/email-payment-info')); ?>">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">
            <input type="hidden" value="<?php echo e($paymentInfo->id); ?>" name="id" id="token">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo e(trans('message.email.email_payment_receipt')); ?></h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label for="email"><?php echo e(trans('message.email.send_to')); ?>:</label>
                  <input type="email" value="<?php echo e($paymentInfo->email); ?>" class="form-control" name="email" id="email">
                </div>
                <?php
                    $subjectText = str_replace('{order_reference_no}', $paymentInfo->order_reference, $emailInfo->subject);
                    $subjectText = str_replace('{invoice_reference_no}', $paymentInfo->invoice_reference, $subjectText);
                    $subjectText = str_replace('{company_name}', Session::get('company_name'), $subjectText);
                 ?>
                <div class="form-group">
                  <label for="subject"><?php echo e(trans('message.email.subject')); ?>:</label>
                  <input type="text" class="form-control" name="subject" id="subject" value="<?php echo e($subjectText); ?>">
                </div>
                  <div class="form-groupa">
                      <?php
                      
                      $bodyInfo = str_replace('{customer_name}', $paymentInfo->name, $emailInfo->body);
                      $bodyInfo = str_replace('{payment_id}', sprintf("%04d", $paymentInfo->id), $bodyInfo);
                      $bodyInfo = str_replace('{payment_method}', $paymentInfo->payment_method, $bodyInfo);
                      $bodyInfo = str_replace('{payment_date}', formatDate($paymentInfo->payment_date), $bodyInfo);
                      $bodyInfo = str_replace('{order_reference_no}', $paymentInfo->order_reference, $bodyInfo);
                      $bodyInfo = str_replace('{total_amount}', Session::get('currency_symbol').number_format($paymentInfo->amount,2,'.',','), $bodyInfo);                      
                      $bodyInfo = str_replace('{invoice_reference_no}', $paymentInfo->invoice_reference, $bodyInfo);
                      $bodyInfo = str_replace('{company_name}', Session::get('company_name'), $bodyInfo);
                      $bodyInfo = str_replace('{billing_state}', $paymentInfo->billing_state, $bodyInfo);                      
                      $bodyInfo = str_replace('{billing_street}', $paymentInfo->billing_street, $bodyInfo);                      
                      $bodyInfo = str_replace('{billing_city}', $paymentInfo->billing_state, $bodyInfo);                      
                      $bodyInfo = str_replace('{billing_zip_code}', $paymentInfo->billing_zip_code, $bodyInfo);                       
                      $bodyInfo = str_replace('{billing_country}', $paymentInfo->billing_country_id, $bodyInfo);
                      ?>
                      <textarea id="compose-textarea" name="message" id='message' class="form-control editor" style="height: 200px"><?php echo e($bodyInfo); ?></textarea>
                  </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"><?php echo e(trans('message.email.close')); ?></button><button type="submit" class="btn btn-primary btn-sm"><?php echo e(trans('message.email.send')); ?></button>
              </div>
            </div>
            </form>
          </div>
        </div>
        <!--Modal end -->
        <!--rightpart-->
        <?php echo $__env->make('layouts.includes.content_right_option', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </section>
    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
        $(".editor").wysihtml5();
      });

    $('#sendPaymentReceipt').validate({
        rules: {
            email: {
                required: true
            },
            subject:{
               required: true,
            },
            message:{
               required: true,
            }                   
        }
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>