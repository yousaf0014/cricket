<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
    <div class="row">
      <div class="col-md-12">
        <div class="box box-default">
        <!-- /.box-header -->
        <div class="box-body">
          <form action="<?php echo e(url('shipment/update')); ?>" method="POST">  
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token"> 
            <input type="hidden" value="<?php echo e($shipment_id); ?>" name="shipment_id" id="shipment_id">
            <div class="row">
              <div class="col-md-4">
                <strong><?php echo e(Session::get('company_name')); ?></strong>
                <h5 class=""><?php echo e(Session::get('company_street')); ?></h5>
                <h5 class=""><?php echo e(Session::get('company_city')); ?>, <?php echo e(Session::get('company_state')); ?></h5>
                <h5 class=""><?php echo e(Session::get('company_country_id')); ?>, <?php echo e(Session::get('company_zipCode')); ?></h5>
              </div>

              <div class="col-md-4">
                <strong><?php echo e(trans('message.extra_text.shiptment_to')); ?></strong>
                <h5><?php echo e(!empty($orderInfo->br_name) ? $orderInfo->br_name : ''); ?></h5>
                <h5><?php echo e(!empty($orderInfo->shipping_street) ? $orderInfo->shipping_street :''); ?></h5>
                <h5><?php echo e(!empty($orderInfo->shipping_city) ? $orderInfo->shipping_city : ''); ?><?php echo e(!empty($orderInfo->shipping_state) ? ', '.$orderInfo->shipping_state : ''); ?></h5>
                <h5><?php echo e(!empty($orderInfo->shipping_country_id) ? $orderInfo->shipping_country_id :''); ?><?php echo e(!empty($orderInfo->shipping_zip_code) ? ', '.$orderInfo->shipping_zip_code : ''); ?></h5>
              </div>
              <div class="col-md-4">
                 <strong><?php echo e(trans('message.invoice.shift_no')); ?> # <a href="<?php echo e(url('shipment/view-details/'.$orderInfo->order_no.'/'.$shipment_id)); ?>"><?php echo e(sprintf("%04d", $shipment_id)); ?></a></strong>
                <h5><?php echo e(trans('message.extra_text.location')); ?> : <?php echo e(getDestinatin($orderInfo->from_stk_loc)); ?></h5>
              </div>

            </div>

            <div class="row">
              <div class="col-md-12">
                <div class="text-center" id="quantityMessage" style="color:red; font-weight:bold">
                </div>
              </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                  <!-- /.box-header -->
                  <div class="box-body no-padding">
                    <div class="table-responsive">
                    <table class="table table-bordered" id="salesInvoice">
                      <tbody>
                      <tr class="tbl_header_color dynamicRows">
                        <th width="30%" class="text-center"><?php echo e(trans('message.table.description')); ?></th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.quantity')); ?></th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.rate')); ?></th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.tax')); ?>(%)</th>
                         <th class="text-center" width="10%"><?php echo e(trans('message.table.discount')); ?>(%)</th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.amount')); ?></th>
                      </tr>
                        <?php
                          $taxAmount      = 0;
                          $subTotalAmount = 0;
                          $qtyTotal       = 0;
                          $priceAmount    = 0;
                          $discount       = 0;
                          $discountPriceAmount = 0;
                        ?>
                        <?php foreach($shipmentItem as $k=>$result): ?>
                             <?php
                              $price = ($result->quantity*$result->unit_price);
                              $discount =  ($result->discount_percent*$price)/100;
                              $discountPriceAmount = ($price-$discount);
                              $qtyTotal +=$result->quantity; 
                              $subTotalAmount += $discountPriceAmount; 
                             ?> 
                                <tr>
                                  <td class="text-center"><?php echo e($result->description); ?></td>
                                  <td>
                                    <input class="form-control text-center no_units" order-no="<?php echo e($result->order_no); ?>" stock-id="<?php echo e($result->stock_id); ?>" min="0" data-id="<?php echo e($result->item_id); ?>" id="qty_<?php echo e($result->item_id); ?>" name="item_quantity[]"  value="<?php echo e($result->quantity); ?>" item-shifted="<?php echo e($result->quantity); ?>" data-tax="<?php echo e($result->tax_rate); ?>" type="text">
                                    <input name="item_id[]" value="<?php echo e($result->item_id); ?>" type="hidden">
                                    <input name="stock_id[]" value="<?php echo e($result->stock_id); ?>" type="hidden">
                                    <input name="previous_qty[]" value="<?php echo e($result->quantity); ?>" type="hidden">
                                    <input name="order_no[]" value="<?php echo e($result->order_no); ?>" type="hidden">
                                  </td>
                                  <td class="text-center">
                                    <?php echo e($result->unit_price); ?>

                                    <input class="form-control text-center unitprice" data-id="<?php echo e($result->item_id); ?>" id="rate_id_<?php echo e($result->item_id); ?>" value="<?php echo e($result->unit_price); ?>" data-tax="<?php echo e($result->tax_rate); ?>" type="hidden" name="unit_price[]">
                                  </td>
                                  <td class="text-center"><?php echo e($result->tax_rate); ?>%<input value="<?php echo e($result->tax_type_id); ?>" type="hidden" name="tax_id[]"></td>
                                  <td class="text-center">
                                    <?php echo e($result->discount_percent); ?>

                                    <input class="form-control text-center discount" data-tax="<?php echo e($result->tax_rate); ?>" data-input-id="<?php echo e($result->item_id); ?>" id="discount_id_<?php echo e($result->item_id); ?>" type="hidden" value="<?php echo e($result->discount_percent); ?>" name="discount[]">
                                  </td>
                                  
                                  <td><input amount-id="<?php echo e($result->item_id); ?>" class="form-control text-center amount tax_item_price_<?php echo e($result->tax_rate); ?>" id="amount_<?php echo e($result->item_id); ?>" value="<?php echo e($discountPriceAmount); ?>" data-tax-rate="<?php echo e($result->tax_rate); ?>" readonly type="text"></td>
                                </tr>
                        <?php endforeach; ?>
                      <tr class="tableInfos"><td colspan="5" align="right"><strong><?php echo e(trans('message.table.sub_total')); ?></strong></td><td align="center" colspan="2"><strong id="subTotal"></strong></td></tr>
                        <?php foreach($taxInfo as $rate=>$tax_amount): ?>
                        <tr class="tax_rate_<?php echo e(str_replace('.','_',$rate)); ?>">
                          <td colspan="5" align="right"><?php echo e(trans('message.invoice.plus_tax')); ?>(<?php echo e($rate); ?>%)</td>
                          <td colspan="2" align="center" class="item-taxs" id="totalTaxs_<?php echo e(str_replace('.','_',$rate)); ?>"><?php echo e($tax_amount); ?></td></tr>
                        <?php
                          $taxAmount += $tax_amount;
                        ?>
                        <?php endforeach; ?>                  
                      <tr class="tableInfos"><td colspan="5" align="right"><strong><?php echo e(trans('message.table.grand_total')); ?></strong></td><td colspan="2"><input type='text' class="form-control text-center" id = "grandTotal" value="<?php echo e($subTotalAmount+$taxAmount); ?>" readonly></td></tr>
                      </tbody>
                    </table>
                    </div>
                    <br><br>
                  </div>
                </div>
                  <!-- /.box-body -->
                <div class="col-md-12">
                  <div class="form-group">
                      <label for="exampleInputEmail1"><?php echo e(trans('message.table.note')); ?></label>
                      <textarea placeholder="<?php echo e(trans('message.table.description')); ?> ..." rows="3" class="form-control" name="comments"></textarea>
                  </div>
                  <a href="<?php echo e(url('/shipment/list')); ?>" class="btn btn-info btn-flat"><?php echo e(trans('message.form.cancel')); ?></a>
                  <button type="submit" class="btn btn-primary btn-flat pull-right" id="btnSubmit"><?php echo e(trans('message.form.submit')); ?></button>
                </div>
            </div>
          </form>
        </div>
    </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
    var token = $("#token").val();
    var shipmentId= $("#shipment_id").val();
     // calculate amount with item quantity
    $(document).on('keyup', '.no_units', function(ev){
      var id = $(this).attr("data-id");
      var order_no = $(this).attr("order-no");
      var stock_id = $(this).attr("stock-id");
      var qty = parseInt($(this).val());
      var shifted_qty = $(this).attr('item-shifted');
      //start check availity of quantity for shipment
        $.ajax({
          url:SITE_URL+'/shipment/quantity-validation',
          method:'POST',
          data  :{stock_id:stock_id,token:token,shipment_id:shipmentId,shifted_qty:shifted_qty,new_qty:qty,order_no:order_no}
        }).done(function(data){
           var data = jQuery.parseJSON(data);
          if(data.status_no == 0){
            $("#quantityMessage").html('Item quantity not available.');
            $('#btnSubmit').attr('disabled', 'disabled');
          }else if(data.status_no == 1){
            $("#quantityMessage").html('');
            $('#btnSubmit').removeAttr('disabled');
          }
        });
      //end check availity of quantity for shipment
       
      var rate = $("#rate_id_"+id).val();
      
      var taxRate = $(this).attr('data-tax');
      
      var newTaxInfo = createTaxId(taxRate);

      var price = calculatePrice(qty,rate);  

      var discountRate = parseFloat($("#discount_id_"+id).val());     

      var discountPrice = calculateDiscountPrice(price,discountRate); 
    
      $("#amount_"+id).val(discountPrice);
      var priceByTaxTpye = calculateTotalByTaxType(taxRate); 
     // console.log(priceByTaxTpye);
      var tax = caculateTax(priceByTaxTpye,taxRate);
     // console.log(tax);
      $("#totalTaxs_"+newTaxInfo).html(tax);

      // Calculate subTotal
      var subTotal = calculateSubTotal();
      $("#subTotal").html(subTotal);
      // Calculate taxTotal
      var taxTotal = calculateTaxTotal();
      // Calculate GrandTotal
      var grandTotal = (subTotal + taxTotal);
      $("#grandTotal").val(grandTotal);
    });

      /**
      * Calcualte Total tax
      *@return  totalTax for row wise
      */
      function calculateTaxTotal (){
          var totalTax = 0;
            $('.item-taxs').each(function() {
                totalTax += parseFloat($(this).text());
            });
            return totalTax;
      }
      
      /**
      * Calcualte Sub Total 
      *@return  subTotal
      */
      function calculateSubTotal (){
        var subTotal = 0;
        $('.amount').each(function() {
            subTotal += parseInt($(this).val());
        });
        return subTotal;
      }

      /**
      * Calcualte Total pice by taxtype 
      *@return  subTotal
      */
      function calculateTotalByTaxType (taxtype){
        var sum = 0;
        $('.tax_item_price_'+taxtype).each(function() {
            sum += parseFloat($(this).val());
        });
        return sum;
      }

      /**
      * Calcualte price
      *@return  price
      */
      function calculatePrice (qty,rate){
         var price = (qty*rate);
         return price;
      }   
      // calculate tax 
      function caculateTax(p,t){
       var tax = (p*t)/100;
       return tax;
      }   
      // calculate taxId replacing dot(.) sign with dash(-) sign
      function createTaxId(taxRate){
        var taxInfo = taxRate.toString();
        var taxId = taxInfo.split('.').join('-');
        return taxId;
      }

      // calculate discont amount
      function calculateDiscountPrice(p,d){
        var discount = [(d*p)/100];
        var result = (p-discount); 
        return result;
      }


    $(document).ready(function(){
        var subTotal = calculateSubTotal();
        $("#subTotal").text(subTotal);
      });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>