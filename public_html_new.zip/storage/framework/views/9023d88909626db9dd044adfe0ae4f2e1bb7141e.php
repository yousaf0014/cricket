<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
        
        <div class="box">
           <div class="panel-body">
                <ul class="nav nav-tabs cus" role="tablist">
                    <li>
                      <a href='<?php echo e(url("customer/edit/$customerData->debtor_no")); ?>' ><?php echo e(trans('message.sidebar.profile')); ?></a>
                    </li>
                    
                    <li>
                      <a href="<?php echo e(url("customer/order/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.sales_orders')); ?></a>
                    </li>
                    <li class="active">
                      <a href="<?php echo e(url("customer/invoice/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.invoices')); ?></a>
                    </li>
                    <li>
                      <a href="<?php echo e(url("customer/payment/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.payments')); ?></a>
                    </li>
                    <li>
                      <a href="<?php echo e(url("customer/shipment/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.deliveries')); ?></a>
                    </li>
               </ul>
              <div class="clearfix"></div>
           </div>
        </div>
        <h3><?php echo e($customerData->name); ?></h3>  
        
        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>

                  <tr>
                    <th><?php echo e(trans('message.table.invoice')); ?></th>
                    <th><?php echo e(trans('message.table.order_no')); ?></th>
                    <th><?php echo e(trans('message.table.total_price')); ?></th>
                    <th><?php echo e(trans('message.table.paid_amount')); ?></th>
                    <th><?php echo e(trans('message.table.paid_status')); ?></th>
                    <th><?php echo e(trans('message.invoice.invoice_date')); ?></th>
                    <th width="10%"><?php echo e(trans('message.table.action')); ?></th>
                  </tr>

                </thead>
                <tbody>
                <?php foreach($salesOrderData as $data): ?>
                  <tr>
                    <td><a href="<?php echo e(URL::to('/')); ?>/invoice/view-detail-invoice/<?php echo e($data->order_reference_id.'/'.$data->order_no); ?>"><?php echo e($data->reference); ?></a></td>
                    <td><a href="<?php echo e(URL::to('/')); ?>/order/view-order-details/<?php echo e($data->order_reference_id); ?>"><?php echo e($data->order_reference); ?></a></td>
                    <td><?php echo e(Session::get('currency_symbol').number_format($data->total,2,'.',',')); ?></td>
                    <td><?php echo e(Session::get('currency_symbol').number_format($data->paid_amount,2,'.',',')); ?></td>
  
                    <?php if($data->paid_amount == 0): ?>
                      <td><span class="label label-danger"><?php echo e(trans('message.invoice.unpaid')); ?></span></td>
                    <?php elseif($data->paid_amount > 0 && $data->total > $data->paid_amount ): ?>
                      <td><span class="label label-warning"><?php echo e(trans('message.invoice.partially_paid')); ?></span></td>
                    <?php elseif($data->paid_amount<=$data->paid_amount): ?>
                      <td><span class="label label-success"><?php echo e(trans('message.invoice.paid')); ?></span></td>
                    <?php endif; ?>

                    <td><?php echo e(formatDate($data->ord_date)); ?></td>
                    <td>
      
                    <?php if(!empty(Session::get('sales_edit'))): ?>
                        <a  title="edit" class="btn btn-xs btn-primary" href='<?php echo e(url("sales/edit/$data->order_no")); ?>'><span class="fa fa-edit"></span></a> &nbsp;
                    <?php endif; ?>
                    <?php if(!empty(Session::get('sales_edit'))): ?>
                      <form method="POST" action="<?php echo e(url("customer/delete-sales-info")); ?>" accept-charset="UTF-8" style="display:inline">
                          <?php echo csrf_field(); ?>

                          <input type="hidden" name="action_name" value="delete_invoice">
                          <input type="hidden" name="invoice_no" value="<?php echo e($data->order_no); ?>">
                          <input type="hidden" name="customer_id" value="<?php echo e($data->debtor_no); ?>">
                          <button title="delete" class="btn btn-xs btn-danger" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.invoice.delete_invoice')); ?>" data-message="<?php echo e(trans('message.invoice.delete_invoice_confirm')); ?>">
                          <i class="fa fa-remove" aria-hidden="true"></i>
                          </button>
                      </form>
                      <?php endif; ?>
                    </td>
                  </tr>               
                <?php endforeach; ?>

                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        
        <!-- /.box-footer-->
    

    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

    $(function () {
      
      
      $("#example1").DataTable({
        "order": [],
        "columnDefs": [ {
          "targets": 3,
          "orderable": false
          } ],

          "language": '<?php echo e(Session::get('dflt_lang')); ?>',
          "pageLength": '<?php echo e(Session::get('row_per_page')); ?>'
      });
      
    });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>