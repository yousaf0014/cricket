<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
      <!-- Default box --> 
        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
                <h4><?php echo e(trans('message.customer_panel.my_invoice')); ?></h4>
            </div>
        </div>

        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th><?php echo e(trans('message.table.invoice')); ?></th>
                    <th><?php echo e(trans('message.table.order_no')); ?></th>
                    
                    <th><?php echo e(trans('message.table.total_price')); ?>(<?php echo e($currency->symbol); ?>)</th>
                    <th><?php echo e(trans('message.table.paid_amount')); ?>(<?php echo e($currency->symbol); ?>)</th>
                    <th><?php echo e(trans('message.table.paid_status')); ?></th>
                    <th><?php echo e(trans('message.invoice.invoice_date')); ?></th>
                   
                  </tr>
                </thead>
                <tbody>
                <?php foreach($salesOrderData as $data): ?>
                  
                  <tr>
                    <td><a href="<?php echo e(URL::to('/')); ?>/customer-panel/view-detail-invoice/<?php echo e($data->order_reference_id.'/'.$data->order_no); ?>"><?php echo e($data->reference); ?></a></td>
                    <td><a href="<?php echo e(URL::to('/')); ?>/customer-panel/view-order-details/<?php echo e($data->order_reference_id); ?>"><?php echo e($data->order_reference); ?></a></td>
                    
                    <td><?php echo e(Session::get('currency_symbol').number_format($data->total,2,'.',',')); ?></td>
                    <td><?php echo e(Session::get('currency_symbol').number_format($data->paid_amount,2,'.',',')); ?></td>
  
                    <?php if($data->paid_amount == 0): ?>
                      <td><span class="label label-danger"><?php echo e(trans('message.invoice.unpaid')); ?></span></td>
                    <?php elseif($data->paid_amount > 0 && $data->total > $data->paid_amount ): ?>
                      <td><span class="label label-warning"><?php echo e(trans('message.invoice.partially_paid')); ?></span></td>
                    <?php elseif($data->paid_amount<=$data->paid_amount): ?>
                      <td><span class="label label-success"><?php echo e(trans('message.invoice.paid')); ?></span></td>
                    <?php endif; ?>

                    <td><?php echo e(formatDate($data->ord_date)); ?></td>
                   
                  </tr>
                 <?php endforeach; ?>

                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        
        <!-- /.box-footer-->
    

    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

    $(function () {
      
      
      $("#example1").DataTable({
        "order": []
      });
      
    });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>