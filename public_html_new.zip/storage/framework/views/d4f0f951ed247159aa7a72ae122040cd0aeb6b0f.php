<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
            <div class="col-md-12">
             <div class="top-bar-title padding-bottom"><?php echo e(trans('message.extra_text.shipment')); ?></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Default box -->
    <div class="row">
      <div class="col-md-8 right-padding-col8">
        <div class="box box-default">
          <div class="box-body">
                <div class="btn-group pull-right">
                  <button title="Email" type="button" class="btn btn-default btn-flat" data-toggle="modal" data-target="#emailShipment"><?php echo e(trans('message.extra_text.email')); ?></button>
                  <a target="_blank" href="<?php echo e(URL::to('/')); ?>/shipment/print/<?php echo e($orderInfo->order_no); ?>/<?php echo e($shipment->id); ?>" title="Print" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.print')); ?></a>
                  <a target="_blank" href="<?php echo e(URL::to('/')); ?>/shipment/pdf/<?php echo e($orderInfo->order_no); ?>/<?php echo e($shipment->id); ?>" title="PDF" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.pdf')); ?></a>
                  
                   <?php if(!empty(Session::get('shipment_edit'))): ?>
                    <a href="<?php echo e(URL::to('/')); ?>/shipment/edit/<?php echo e($shipment->id); ?>" title="Edit" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.edit')); ?></a>
                   <?php endif; ?>
                  <?php if($shipment->status == 0): ?>
                  <?php if(!empty(Session::get('shipment_edit'))): ?>
                  <a href="<?php echo e(URL::to('/')); ?>/shipment/delivery/<?php echo e($orderInfo->order_no); ?>/<?php echo e($shipment->id); ?>" title="Deliver" class="btn btn-default btn-flat success-btn"><?php echo e(trans('message.extra_text.deliver')); ?></a>
                  <?php endif; ?>
                  <?php endif; ?>
                 <?php if(!empty(Session::get('shipment_delete'))): ?>
                  <form method="POST" action="<?php echo e(url("shipment/delete/$shipment->id")); ?>" accept-charset="UTF-8" style="display:inline">
                      <?php echo csrf_field(); ?>

                      <button class="btn btn-default btn-flat delete-btn" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.invoice.delete_shipment')); ?>" data-message="<?php echo e(trans('message.invoice.delete_shipment_confirm')); ?>">
                         <?php echo e(trans('message.extra_text.delete')); ?>

                      </button>
                  </form>
                  <?php endif; ?>
                </div>
          </div>

          <div class="box-body">
            <div class="row">
                  <div class="col-md-4">
                    <strong><?php echo e(Session::get('company_name')); ?></strong>
                    <h5 class=""><?php echo e(Session::get('company_street')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_city')); ?>, <?php echo e(Session::get('company_state')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_country_id')); ?>, <?php echo e(Session::get('company_zipCode')); ?></h5>
                  </div>

                  <div class="col-md-4">
                  <strong><?php echo e(trans('message.extra_text.shiptment_to')); ?></strong>
                  <h5><?php echo e(!empty($customerInfo->br_name) ? $customerInfo->br_name : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_street) ? $customerInfo->shipping_street :''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_city) ? $customerInfo->shipping_city : ''); ?><?php echo e(!empty($customerInfo->shipping_state) ? ', '.$customerInfo->shipping_state : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_country_id) ? $customerInfo->shipping_country_id :''); ?><?php echo e(!empty($customerInfo->shipping_zip_code) ? ', '.$customerInfo->shipping_zip_code : ''); ?></h5>
                  </div>
                
                <div class="col-md-4">
                    <strong class=""><?php echo e(trans('message.invoice.shift_no').' # '.sprintf("%04d", $shipment->id)); ?></strong>
                   <h5><?php echo e(trans('message.extra_text.location')); ?> : <?php echo e($orderInfo->location_name); ?></h5>
                   <?php
                      if($shipment->status == 0){
                        $status = trans('message.invoice.shipment_packed');
                      }else{
                        $status = trans('message.invoice.shipment_delivered');
                      }
                   ?>
                   <h5><?php echo e(trans('message.invoice.status')); ?> : <?php echo e($status); ?> </h5>
                   <?php if($shipment->status == 1): ?>
                   <h5><?php echo e(trans('message.invoice.deliver_date')); ?> : <?php echo e(formatDate($shipment->delivery_date)); ?></h5>
                    <?php endif; ?>
                </div>
            </div>
          </div>

          <div class="box-body">
            <div class="row">
              <div class="col-md-12">
                  <div class="table-responsive">
                      <table class="table table-bordered">
                        <tbody>
                        <tr class="tbl_header_color">
                          <th width="5%" class="text-left"><?php echo e(trans('message.invoice.shipment_no')); ?></th>
                          <th width="30%" class="text-left"><?php echo e(trans('message.table.description')); ?></th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.quantity')); ?></th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.rate')); ?>(<?php echo e(Session::get('currency_symbol')); ?>)</th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.tax')); ?>(%)</th>
                          <th class="text-center" width="10%"><?php echo e(trans('message.table.discount')); ?>(%)</th>
                          <th width="15%" class="text-center"><?php echo e(trans('message.table.amount')); ?>(<?php echo e(Session::get('currency_symbol')); ?>)</th>
                        </tr>
                        <?php
                          $taxAmount      = 0;
                          $subTotalAmount = 0;
                          $qtyTotal       = 0;
                          $priceAmount    = 0;
                          $discount       = 0;
                          $discountPriceAmount = 0;
                          $itemsInformation = '';
                        ?>
                          <?php foreach($shipmentItem as $k=>$result): ?>
                             <?php
                              $price = ($result->quantity*$result->unit_price);
                              $discount =  ($result->discount_percent*$price)/100;
                              $discountPriceAmount = ($price-$discount);
                              $qtyTotal +=$result->quantity; 
                              $subTotalAmount += $discountPriceAmount; 
                             // Create item information for email template
                              $itemsInformation .= '<div>'.$result->quantity.'x'.' '.$result->description.'</div>';
                             ?> 
                             <?php if($result->quantity>0): ?>
                            <tr>
                              <td class="text-left"><?php echo e(++$k); ?></td>
                              <td class="text-left"><?php echo e($result->description); ?></td>
                              <td class="text-center"><?php echo e($result->quantity); ?></td>
                              <td class="text-center"><?php echo e(number_format($result->unit_price,2,'.',',')); ?></td>
                              <td class="text-center"><?php echo e(number_format($result->tax_rate,2,'.',',')); ?></td>
                              <td class="text-center"><?php echo e(number_format($result->discount_percent,2,'.',',')); ?></td>
                              <td class="text-right"><?php echo e(number_format($discountPriceAmount,2,'.',',')); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <tr><td colspan="6" align="right"><?php echo e(trans('message.table.total_quantity')); ?></td><td align="right"><?php echo e($qtyTotal); ?></td></tr>
                            <tr><td colspan="6" align="right"><strong><?php echo e(trans('message.table.sub_total')); ?></strong></td><td align="right"><strong><?php echo e(Session::get('currency_symbol').number_format($subTotalAmount,2,'.',',')); ?></strong></td></tr>
                            
                            <?php foreach($taxInfo as $rate=>$tax_amount): ?>
                            <?php if($rate != 0): ?>
                            <tr>
                              <td colspan="6" align="right"><?php echo e(trans('message.invoice.plus_tax')); ?>(<?php echo e($rate); ?>%)</td>
                              <td colspan="2" align="right"><?php echo e(Session::get('currency_symbol').number_format($tax_amount,2,'.',',')); ?></td></tr>
                            <?php
                              $taxAmount += $tax_amount;
                            ?>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <tr class="tableInfos">
                              <td colspan="6" align="right"><strong><?php echo e(trans('message.table.grand_total')); ?></strong></td>
                              <td align="right" colspan="2"><strong><?php echo e(Session::get('currency_symbol').number_format(($subTotalAmount+$taxAmount),2,'.',',')); ?></strong></td>
                            </tr>
                         
                        </tbody>
                      </table>
                  </div>
              </div>
            </div>
          </div>

        </div>
      </div>
        <!--Modal start-->
        <div id="emailShipment" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <form id="sendShipmentInfo" method="POST" action="<?php echo e(url('shipment/email-shipment-info')); ?>">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">
            <input type="hidden" value="<?php echo e($orderInfo->order_no); ?>" name="order_id" id="order_id">
            <input type="hidden" value="<?php echo e($shipment->id); ?>" name="shipment_id" id="shipment_id">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo e(trans('message.email.email_shipment_info')); ?></h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label for="email"><?php echo e(trans('message.email.send_to')); ?>:</label>
                  <input type="email" value="<?php echo e($customerInfo->email); ?>" class="form-control" name="email" id="email">
                </div>
                <?php
                $subjectInfo = str_replace('{order_reference_no}', $orderInfo->reference, $emailInfo->subject);
                $subjectInfo = str_replace('{company_name}', Session::get('company_name'), $subjectInfo);
                ?>
                <div class="form-group">
                  <label for="subject"><?php echo e(trans('message.email.subject')); ?>:</label>
                  <input type="text" class="form-control" name="subject" id="subject" value="<?php echo e($subjectInfo); ?>">
                </div>
                  <div class="form-groupa">
                      <?php
                      $packed_on = date('Y-m-d',strtotime($shipment->packed_date));
                      if(!empty($shipment->delivery_date)){
                      $delivery_on = date('Y-m-d',strtotime($shipment->delivery_date));
                      $delivery_on = formatDate($delivery_on);
                      }else{
                        $delivery_on = '';
                      }
                      //d($packed_on,1);
                      $bodyInfo = str_replace('{customer_name}', $customerInfo->name, $emailInfo->body);
                      $bodyInfo = str_replace('{order_reference_no}', $orderInfo->reference, $bodyInfo);
                      $bodyInfo = str_replace('{packed_date}',formatDate($packed_on), $bodyInfo);
                      $bodyInfo = str_replace('{delivery_date}',$delivery_on, $bodyInfo);
                      $bodyInfo = str_replace('{shipping_street}', $customerInfo->shipping_street, $bodyInfo);
                      $bodyInfo = str_replace('{shipping_city}', $customerInfo->shipping_city, $bodyInfo);
                      $bodyInfo = str_replace('{shipping_state}', $customerInfo->shipping_state, $bodyInfo);
                      $bodyInfo = str_replace('{shipping_zip_code}', $customerInfo->shipping_zip_code, $bodyInfo);
                      $bodyInfo = str_replace('{shipping_country}', $customerInfo->shipping_country_id, $bodyInfo);                      
                      $bodyInfo = str_replace('{company_name}', Session::get('company_name'), $bodyInfo);
                      $bodyInfo = str_replace('{item_information}', $itemsInformation, $bodyInfo);                     
                      ?>
                      <textarea id="compose-textarea" name="message" id='message' class="form-control editor" style="height: 200px"><?php echo e($bodyInfo); ?></textarea>
                  </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"><?php echo e(trans('message.email.close')); ?></button><button type="submit" class="btn btn-primary btn-sm"><?php echo e(trans('message.email.send')); ?></button>
              </div>
            </div>
            </form>
          </div>
        </div>
        <!--Modal end -->

      <?php echo $__env->make('layouts.includes.content_right_option', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    </section>
<?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
        $(".editor").wysihtml5();
      });

    $('#sendShipmentInfo').validate({
        rules: {
            email: {
                required: true
            },
            subject:{
               required: true,
            },
            message:{
               required: true,
            }                   
        }
    });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>