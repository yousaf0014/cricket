<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="box box-default">
      <div class="box-body">
        <div class="row">
          <div class="col-md-10">
           <div class="top-bar-title padding-bottom"><?php echo e(trans('message.customer_panel.my_order')); ?></div>
          </div> 
          <div class="col-md-2">
            
              <a href="<?php echo e(url('customer-panel/order/add')); ?>" class="btn btn-block btn-default btn-flat btn-border-orange"><?php echo e(trans('message.form.add_new_order')); ?></a>
            
          </div>
        </div>
      </div>
    </div>
      <!-- Default box --> 
        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="orderList" class="table table-bordered table-striped">
                <thead>
              
                  <tr>
                    <th><?php echo e(trans('message.table.order')); ?></th>
                    <th><?php echo e(trans('message.invoice.ordered')); ?></th>
                    <th><?php echo e(trans('message.invoice.invoiced')); ?></th>
                    <th><?php echo e(trans('message.invoice.packed')); ?></th>
                    <th><?php echo e(trans('message.invoice.paid')); ?></th>
                    <th><?php echo e(trans('message.table.total')); ?>(<?php echo e($currency->symbol); ?>)</th>
                    <th><?php echo e(trans('message.table.ord_date')); ?></th>
                  </tr>
                
                </thead>
                <tbody>
                <?php foreach($salesOrderData as $data): ?>
                <tr>
                    <td> <a title="view" href="<?php echo e(url("customer-panel/view-order-details/$data->order_no")); ?>"><?php echo e($data->reference); ?></a></td>
                    
                    <td><?php echo e($data->ordered_quantity); ?></td>

                    <?php if( $data->invoiced_quantity == 0 ): ?>
                    <td><span class="fa fa-circle-thin"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->invoiced_quantity)== 0): ?>
                    <td><span class="fa fa-circle"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->invoiced_quantity)>0): ?>
                    <td><span class="glyphicon glyphicon-adjust"></span></td>
                    <?php endif; ?>


                    <?php if( $data->packed_qty == 0 ): ?>
                    <td><span class="fa fa-circle-thin"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->packed_qty)== 0): ?>
                    <td><span class="fa fa-circle"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->packed_qty)>0): ?>
                    <td><span class="glyphicon glyphicon-adjust"></span></td>
                    <?php endif; ?>

                    <?php if( $data->paid_amount == 0 ): ?>
                    <td><span class="fa fa-circle-thin"></span></td>
                    <?php elseif(abs($data->order_amount) - abs($data->paid_amount)== 0): ?>
                    <td><span class="fa fa-circle"></span></td>
                    <?php elseif(abs($data->order_amount) - abs($data->paid_amount)>0): ?>
                    <td><span class="glyphicon glyphicon-adjust"></span></td>
                    <?php endif; ?>

                    <td><?php echo e(number_format($data->order_amount,2,'.',',')); ?></td>
                    <td><?php echo e(formatDate($data->ord_date)); ?></td>
                </tr>
               <?php endforeach; ?>

                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        
        <!-- /.box-footer-->
    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

  $(function () {
    $("#orderList").DataTable({
      "order": [],
    });
    
  });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>