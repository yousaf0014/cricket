<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

    <div class="box box-default">
      <div class="box-body">
        <div class="row">
          <div class="col-md-12">
           <div class="top-bar-title padding-bottom"><?php echo e(trans('message.extra_text.customer')); ?></div>
          </div> 
        </div>
      </div>
    </div> 
        
        <div class="box">
                <!-- form start -->
                      <form action="<?php echo e(url('save-customer')); ?>" method="post" id="customerAdd" class="form-horizontal">
                      
                      <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">
                      <div class="box-body">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="col-md-6">
                            <h4 class="text-info text-center"><?php echo e(trans('message.invoice.customer_info')); ?></h4>
                            <div class="form-group">
                              <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.form.name')); ?></label>

                              <div class="col-sm-8">
                                <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                              </div>
                            </div>
                            
                            <div class="form-group">
                              <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.form.email')); ?></label>

                              <div class="col-sm-8">
                                <input type="email" value="<?php echo e(old('email')); ?>" class="form-control" name="email">
                              </div>
                            </div>
                            
                            <div class="form-group">
                              <label class="col-sm-4 control-label" for="inputEmail3"><?php echo e(trans('message.table.phone')); ?></label>

                              <div class="col-sm-8">
                                <input type="text" value="<?php echo e(old('phone')); ?>" class="form-control" name="phone">
                              </div>
                            </div>

                            <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.street')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" name="bill_street" value="<?php echo e(old('bill_street')); ?>" id="bill_street">
                                  </div>
                                </div>
                                
                                <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.city')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" name="bill_city" value="<?php echo e(old('bill_city')); ?>" id="bill_city">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.state')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" name="bill_state" value="<?php echo e(old('bill_state')); ?>" id="bill_state">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="col-sm-4 control-label" for="inputEmail3"><?php echo e(trans('message.invoice.zipcode')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" name="bill_zipCode" value="<?php echo e(old('bill_zipCode')); ?>" id="bill_zipCode">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.country')); ?></label>

                                  <div class="col-sm-8">
                                    <select class="form-control select2" name="bill_country_id" id="bill_country_id">
                                    <option value=""><?php echo e(trans('message.form.select_one')); ?></option>
                                    <?php foreach($countries as $data): ?>
                                      <option value="<?php echo e($data->code); ?>"><?php echo e($data->country); ?></option>
                                    <?php endforeach; ?>
                                    </select>
                                  </div>
                                </div>
                          </div>
                          
                          <div class="col-md-6">
                              <h4 class="text-info text-center"><?php echo e(trans('message.invoice.shipping_address')); ?> <button id="copy" class="btn btn-default btn-xs" type="button">Copy Address</button></h4>

                                <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.street')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ship_street" name="ship_street">
                                  </div>
                                </div>
                                
                                <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.city')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ship_city" name="ship_city">
                                  </div>
                                </div>
                                <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.state')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ship_state" name="ship_state">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="col-sm-4 control-label" for="inputEmail3"><?php echo e(trans('message.invoice.zipcode')); ?></label>

                                  <div class="col-sm-8">
                                    <input type="text" class="form-control" id="ship_zipCode" name="ship_zipCode">
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label class="col-sm-4 control-label require" for="inputEmail3"><?php echo e(trans('message.invoice.country')); ?></label>

                                  <div class="col-sm-8">
                                    <select class="form-control select2" name="ship_country_id" id="ship_country_id">
                                    <option value=""><?php echo e(trans('message.form.select_one')); ?></option>
                                    <?php foreach($countries as $data): ?>
                                      <option value="<?php echo e($data->code); ?>"><?php echo e($data->country); ?></option>
                                    <?php endforeach; ?>
                                    </select>
                                  </div>
                                </div>
                          </div>
                          
                        </div>
                      </div><br>
                      </div>
                        <!-- /.box-body -->
                        
                        <div class="box-footer">
                          <a href="<?php echo e(url('customer/list')); ?>" class="btn btn-info btn-flat"><?php echo e(trans('message.form.cancel')); ?></a>
                          <button class="btn btn-primary pull-right btn-flat" type="submit"><?php echo e(trans('message.form.submit')); ?></button>
                        </div>
                        <!-- /.box-footer -->
                      </form>
          
        </div>
        
        <!-- /.box-footer-->
      
      <!-- /.box -->

    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

    $(".select2").select2();
      // Item form validation
    $('#customerAdd').validate({
        rules: {
            name: {
                required: true
            },
            email:{
                required: true
            },

            bill_street: {
                required: true
            },
            bill_city:{
                required: true
            },
            bill_state:{
               required: true
            },
            bill_country_id:{
               required: true
            },
           
            ship_street: {
                required: true
            },
            ship_city:{
                required: true
            },
            ship_state:{
               required: true
            },
            ship_country_id:{
               required: true
            }

        }
    });

    $('#copy').on('click', function() {

        $('#ship_street').val($('#bill_street').val());
        $('#ship_city').val($('#bill_city').val());
        $('#ship_state').val($('#bill_state').val());
        $('#ship_zipCode').val($('#bill_zipCode').val());

       var bill_country = $('#bill_country_id').val();
       
       $("#ship_country_id").val(bill_country).change();;

    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>