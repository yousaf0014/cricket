<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="box">
        <div class="box-body">
          <div class="col-md-6 col-xs-12">
              <div class="row">
            <form class="form-horizontal" action="<?php echo e(url('report/sales-report')); ?>" method="get">
              
              <div class="col-md-5">
                  <label for="exampleInputEmail1"><?php echo e(trans('message.report.from')); ?></label>
                  <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input class="form-control" id="from" type="text" name="from">
                  </div>
              </div>

              <div class="col-md-5">
                  <label for="exampleInputEmail1"><?php echo e(trans('message.report.to')); ?></label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                    <input class="form-control" id="to" type="text" name="to">
                  </div>
              </div>

              <div class="col-md-2">
                <label for="btn">&nbsp;</label>
                <button type="submit" name="btn" class="btn btn-primary btn-flat"><?php echo e(trans('message.extra_text.filter')); ?></button>
              </div>
            </form>
          </div>
          </div>
          <div class="col-md-6 col-xs-12">
            <br>
            <div class="btn-group pull-right">
              <a href="<?php echo e(URL::to('/')); ?>/report/sales-report-csv" title="CSV" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.csv')); ?></a>
              <a href="<?php echo e(URL::to('/')); ?>/report/sales-report-pdf" title="PDF" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.pdf')); ?></a>
            </div>

          </div>

        </div>
        <br>
      </div><!--Top Box End-->
      <!-- Default box -->
      <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="salesList" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th class="text-center"><?php echo e(trans('message.report.date')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.report.sales_volume')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.report.sales_value')); ?>(<?php echo e(Session::get('currency_symbol')); ?>)</th>
                  <th class="text-center"><?php echo e(trans('message.report.no_of_orders')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php
                  $qty = 0;
                  $price = 0;
                  $order = 0;
                ?>
                <?php foreach($itemList as $item): ?>
                <?php
                $qty += $item->qty; 
                $price += ($item->price-$item->discount); 
                $order += $item->no_of_order;
                ?>
                <tr>
                  <td class="text-center"><a href="<?php echo e(URL::to('/')); ?>/report/sales-report-by-date/<?php echo e(strtotime($item->ord_date)); ?>"><?php echo e(formatDate($item->ord_date)); ?></a></td>
                  <td class="text-center"><?php echo e($item->qty); ?></td>
                  <td class="text-center"><?php echo e(number_format(($item->price-$item->discount),2,'.',',')); ?></td>
                  <td class="text-center"><?php echo e($item->no_of_order); ?></td>
                </tr>
               <?php endforeach; ?>
               
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
      <!-- /.box -->
    </section>

<?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(function () {
  $(".select2").select2({});
    
    $('#from').datepicker({
        autoclose: true,
        todayHighlight: true,
        format: '<?php echo e(Session::get('date_format_type')); ?>'
    });
    $('#from').datepicker('update', new Date());

    $('#to').datepicker({
        autoclose: true,
        todayHighlight: true,
        
        format: '<?php echo e(Session::get('date_format_type')); ?>'
    });
    $('#to').datepicker('update', new Date());


    $("#salesList").DataTable({
      "order": [],

      "columnDefs": [ {
        "targets": 3,
        "orderable": true
        } ],

        "language": '<?php echo e(Session::get('dflt_lang')); ?>',
        "pageLength": '<?php echo e(Session::get('row_per_page')); ?>'
    });
    
  });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>