<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
    
      <div class="row">
        <div class="col-md-3">
          <?php echo $__env->make('layouts.includes.company_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- /.col -->
        <div class="col-md-9">

          <div class="box box-default">
            <div class="box-body">
              <div class="row">
                <div class="col-md-9">
                 <div class="top-bar-title padding-bottom"><?php echo e(trans('message.extra_text.location')); ?></div>
                </div> 
                <div class="col-md-3">
                  <?php if(!empty(Session::get('loc_add'))): ?>
                    <a href="<?php echo e(url('create-location')); ?>" class="btn btn-block btn-default btn-flat btn-border-orange"><?php echo e(trans('message.table.add_new_loc')); ?></a>
                   <?php endif; ?>
                </div>
              </div>
            </div>
          </div>

          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th><?php echo e(trans('message.table.location_name')); ?></th>
                  <th><?php echo e(trans('message.table.location_code')); ?></th>
                  <th><?php echo e(trans('message.table.delivery_address')); ?></th>
                  <th><?php echo e(trans('message.form.default_loc')); ?></th>
                  <th><?php echo e(trans('message.table.phone')); ?></th>
                  <th width="5%"><?php echo e(trans('message.table.action')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($locationData as $data): ?>
                <tr>
                  <td><a href="<?php echo e(url("edit-location/$data->id")); ?>"><?php echo e($data->location_name); ?></a></td>
                  <td><?php echo e($data->loc_code); ?></td>
                  <td><?php echo e($data->delivery_address); ?></td>
                  
                  <td><?php echo e($data->inactive == 1 ? 'Yes':"No"); ?></td>
                  <td><?php echo e($data->contact); ?></td>
                  <td>
                  <?php if(!empty(Session::get('loc_edit'))): ?>
                      <a title="<?php echo e(trans('message.form.edit')); ?>" class="btn btn-xs btn-primary" href='<?php echo e(url("edit-location/$data->id")); ?>'><span class="fa fa-edit"></span></a> &nbsp;
                  <?php endif; ?>

                  <?php if(!empty(Session::get('loc_delete'))): ?>
                       <?php if(!in_array($data->id,[1])): ?>
                      <form method="POST" action="<?php echo e(url("delete-location/$data->id")); ?>" accept-charset="UTF-8" style="display:inline">
                          <?php echo csrf_field(); ?>

                          <button title="<?php echo e(trans('message.form.Delete')); ?>" class="btn btn-xs btn-danger" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.table.delete_location_header')); ?>" data-message="<?php echo e(trans('message.table.delete_location')); ?>">
                              <i class="glyphicon glyphicon-trash"></i> 
                          </button>
                      </form>
                      <?php endif; ?>
                  <?php endif; ?>

                  </td>
                </tr>
               <?php endforeach; ?>
                </tfoot>
              </table>
            </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      </div>

    </section>
    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
        $("#example1").DataTable({
          "columnDefs": [ {
            "targets": 5,
            "orderable": false
            } ],

            "language": '<?php echo e(Session::get('dflt_lang')); ?>',
            "pageLength": '<?php echo e(Session::get('row_per_page')); ?>'
        });
        
      });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>