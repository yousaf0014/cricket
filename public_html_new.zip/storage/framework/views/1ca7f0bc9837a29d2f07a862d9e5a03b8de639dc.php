<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">
          <?php echo $__env->make('layouts.includes.sub_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- /.col -->
        <div class="col-md-9">

          <div class="box box-default">
            <div class="box-body">
              <div class="row">
                <div class="col-md-9">
                 <div class="top-bar-title padding-bottom"><?php echo e(trans('message.table.backup')); ?></div>
                </div> 
                <div class="col-md-3">
                  <?php if(!empty(Session::get('backup_add'))): ?>
                    <a href="<?php echo e(url('back-up')); ?>" class="btn btn-block btn-default btn-flat btn-border-orange"><?php echo e(trans('message.extra_text.new_backup')); ?></a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>

          <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>#</th>
                  <th><?php echo e(trans('message.table.name')); ?></th>
                  <th><?php echo e(trans('message.table.date')); ?></th>
                  <th width="5%"><?php echo e(trans('message.table.action')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php $i = 0;?>
                <?php foreach($backupData as $data): ?>
                <tr>
                  <td><?php echo e(++$i); ?></td>
                  <td><?php echo e($data->name); ?></td>
                  <td><?php echo e($data->created_at); ?></td>
                  <td>
              
              <?php if(!empty(Session::get('backup_download'))): ?>
                      <a  title="Download" href="<?php echo e(URL::to('/storage/laravel-backups/'.$data->name)); ?>"  class="btn btn-xs btn-danger edit_unit" id="<?php echo e($data->id); ?>" ><span class="fa fa-download"></span></a> &nbsp;
              <?php endif; ?>
            
                  </td>
                </tr>
               <?php endforeach; ?>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>

    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
        $("#example1").DataTable({
          "order": [],
          "columnDefs": [ {
            "targets": 3,
            "orderable": false
            } ],
            
            "language": '<?php echo e(Session::get('dflt_lang')); ?>',
            "pageLength": '<?php echo e(Session::get('row_per_page')); ?>'
        });
        
      });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>