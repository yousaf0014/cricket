<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
    <div class="row">
      <div class="col-md-12">
        <div class="box box-default">
        <!-- /.box-header -->
          <div class="box-body">
                <div class="row">
                  <div class="col-md-4">
                    <strong><?php echo e($settings[8]->value); ?></strong>
                    <h5><?php echo e($settings[11]->value); ?></h5>
                    <h5><?php echo e($settings[12]->value); ?>, <?php echo e($settings[13]->value); ?></h5>
                    <h5><?php echo e($settings[15]->value); ?>, <?php echo e($settings[14]->value); ?></h5>
                  </div>
                  
                  <div class="col-md-4">
                  <strong><?php echo e(trans('message.extra_text.shiptment_to')); ?></strong>
                  <h5><?php echo e(!empty($customerInfo->br_name) ? $customerInfo->br_name : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_street) ? $customerInfo->shipping_street :''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_city) ? $customerInfo->shipping_city : ''); ?> <?php echo e(!empty($customerInfo->shipping_state) ? ', '.$customerInfo->shipping_state : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_country_id) ? $customerInfo->shipping_country_id :''); ?> <?php echo e(!empty($customerInfo->shipping_zip_code) ? ', '.$customerInfo->shipping_zip_code : ''); ?></h5>
                  </div>


                  <div class="col-md-4">
                  <strong><?php echo e(trans('message.invoice.shift_no').' # '.sprintf("%04d", $shipment->id)); ?></strong>
                   <?php
                      if($shipment->status == 0){
                        $status = trans('message.invoice.shipment_packed');
                      }else{
                        $status = trans('message.invoice.shipment_delivered');
                      }
                   ?>
                   <h5 class="text-primary"><strong><?php echo e(trans('message.invoice.status').' # '.$status); ?></strong></h5>
                   <?php if($shipment->status == 1): ?>
                   <h5><?php echo e(trans('message.invoice.deliver_date')); ?> : <?php echo e(formatDate($shipment->delivery_date)); ?></h5>
                    <?php endif; ?>
                  </div>

                </div>
          </div>

          <div class="box-body">
            <div class="row">
              <div class="col-md-12">
                  <div class="table-responsive">
                      <table class="table table-bordered">
                        <tbody>
                        <tr class="tbl_header_color">
                          <th width="5%" class="text-left"><?php echo e(trans('message.invoice.shipment_no')); ?></th>
                          <th width="30%" class="text-left"><?php echo e(trans('message.table.description')); ?></th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.quantity')); ?></th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.rate')); ?>(<?php echo e($currency->symbol); ?>)</th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.tax')); ?>(%)</th>
                          <th class="text-center" width="10%"><?php echo e(trans('message.table.discount')); ?>(%)</th>
                          <th width="15%" class="text-center"><?php echo e(trans('message.table.amount')); ?>(<?php echo e($currency->symbol); ?>)</th>
                        </tr>
                        <?php
                          $taxAmount      = 0;
                          $subTotalAmount = 0;
                          $qtyTotal       = 0;
                          $priceAmount    = 0;
                          $discount       = 0;
                          $discountPriceAmount = 0;
                          $itemsInformation = '';
                        ?>
                          <?php foreach($shipmentItem as $k=>$result): ?>
                             <?php
                              $price = ($result->quantity*$result->unit_price);
                              $discount =  ($result->discount_percent*$price)/100;
                              $discountPriceAmount = ($price-$discount);
                              $qtyTotal +=$result->quantity; 
                              $subTotalAmount += $discountPriceAmount; 
                             // Create item information for email template
                              $itemsInformation .= '<div>'.$result->quantity.'x'.' '.$result->description.'</div>';
                             ?> 
                             <?php if($result->quantity>0): ?>
                            <tr>
                              <td class="text-left"><?php echo e(++$k); ?></td>
                              <td class="text-left"><?php echo e($result->description); ?></td>
                              <td class="text-center"><?php echo e($result->quantity); ?></td>
                              <td class="text-center"><?php echo e(number_format($result->unit_price,2,'.',',')); ?></td>
                              <td class="text-center"><?php echo e(number_format($result->tax_rate,2,'.',',')); ?></td>
                              <td class="text-center"><?php echo e(number_format($result->discount_percent,2,'.',',')); ?></td>
                              <td class="text-right"><?php echo e(number_format($discountPriceAmount,2,'.',',')); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <tr><td colspan="6" align="right"><?php echo e(trans('message.table.total_quantity')); ?></td><td align="right"><?php echo e($qtyTotal); ?></td></tr>
                            <tr><td colspan="6" align="right"><strong><?php echo e(trans('message.table.sub_total')); ?></strong></td><td align="right"><strong><?php echo e($currency->symbol.number_format($subTotalAmount,2,'.',',')); ?></strong></td></tr>
                            
                            <?php foreach($taxInfo as $rate=>$tax_amount): ?>
                            <?php if($rate != 0): ?>
                            <tr>
                              <td colspan="6" align="right"><?php echo e(trans('message.invoice.plus_tax')); ?>(<?php echo e($rate); ?>%)</td>
                              <td colspan="2" align="right"><?php echo e($currency->symbol.number_format($tax_amount,2,'.',',')); ?></td></tr>
                            <?php
                              $taxAmount += $tax_amount;
                            ?>
                            <?php endif; ?>
                            <?php endforeach; ?>
                            <tr class="tableInfos">
                              <td colspan="6" align="right"><strong><?php echo e(trans('message.table.grand_total')); ?></strong></td>
                              <td align="right" colspan="2"><strong><?php echo e($currency->symbol.number_format(($subTotalAmount+$taxAmount),2,'.',',')); ?></strong></td>
                            </tr>
                         
                        </tbody>
                      </table>
                  </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
    </section>
  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>