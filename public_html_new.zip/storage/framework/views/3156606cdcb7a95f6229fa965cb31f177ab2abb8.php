<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
    <div class="row">
        <div class="col-md-12">
            <div class="box box-default">
              <div class="box-body">
                <div class="row">
                  <div class="col-md-4">
                   <strong class="text-info"><?php echo e(trans('message.invoice.payment_no').' # '.sprintf("%04d", $paymentInfo->id)); ?></strong>
                  </div>
                </div>
              </div>

              <div class="box-body">
                <div class="row">
                  <div class="col-md-6">
                    <strong><?php echo e($settings[8]->value); ?></strong>
                    <h5><?php echo e($settings[11]->value); ?></h5>
                    <h5><?php echo e($settings[12]->value); ?>, <?php echo e($settings[13]->value); ?></h5>
                    <h5><?php echo e($settings[15]->value); ?>, <?php echo e($settings[14]->value); ?></h5>
                  </div>
                  <div class="col-md-6 text-right">
                    <h5><?php echo e($paymentInfo->name); ?></h5>
                    <h5><?php echo e($paymentInfo->br_address); ?></h5>
                    <h5><?php echo e($paymentInfo->billing_street); ?></h5>
                    <h5><?php echo e($paymentInfo->billing_city); ?>, <?php echo e($paymentInfo->billing_state); ?></h5>
                    <h5><?php echo e($paymentInfo->billing_country_id); ?>, <?php echo e($paymentInfo->billing_zip_code); ?></h5>                    
                  </div>
                </div>
                <h3 class="text-center">PAYMENT RECEIPT</h3>
                  <div class="row">
                    <div class="col-md-6">
                      <h5><?php echo e(trans('message.invoice.payment_date')); ?> : <?php echo e(formatDate($paymentInfo->payment_date)); ?></h5>
                      <h5><?php echo e(trans('message.invoice.payment_on')); ?> : <?php echo e($paymentInfo->payment_method); ?></h5>
                      <div class="well well-lg label-primary text-center"><strong><?php echo e(trans('message.invoice.total_amount')); ?><br/><?php echo e(Session::get('currency_symbol').number_format($paymentInfo->amount,2,'.',',')); ?></strong></div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="table-responsive">
                          <table class="table table-bordered">
                            <tbody>
                              <tr class="tbl_header_color dynamicRows">
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.order_no')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.invoice_no')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.invoice_date')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.invoice_amount')); ?></th>
                                <th width="20%" class="text-center"><?php echo e(trans('message.invoice.paid_amount')); ?></th>
                              </tr>
                              <tr>
                                <td width="20%" class="text-center"><?php echo e($paymentInfo->order_reference); ?></td>
                                <td width="20%" class="text-center"><?php echo e($paymentInfo->invoice_reference); ?></td>
                                <td width="20%" class="text-center"><?php echo e(formatDate($paymentInfo->invoice_date)); ?></td>
                                <td width="20%" class="text-center"><?php echo e(Session::get('currency_symbol').number_format($paymentInfo->invoice_amount,2,'.',',')); ?></td>
                                <td width="20%" class="text-center"><?php echo e(Session::get('currency_symbol').number_format($paymentInfo->amount,2,'.',',')); ?></td>
                              </tr>
                            </tbody>
                          </table>
                      </div>
                      </div>
                  </div>
              </div>
            </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script type="text/javascript">
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>