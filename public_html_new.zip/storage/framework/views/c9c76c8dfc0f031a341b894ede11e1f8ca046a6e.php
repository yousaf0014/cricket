<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      
      <ul class="sidebar-menu">
        
        <li <?= $menu == 'dashboard' ? ' class="active"' : ''?> >
          <a href="<?php echo e(url('dashboard')); ?>">
            <i class="fa fa-dashboard"></i> <span><?php echo e(trans('message.sidebar.dashboard')); ?> </span>
          </a>
        </li>

        <li <?= $menu == 'customer' ? ' class="active"' : ''?> >
          <a href="<?php echo e(url('customer/list')); ?>">
            <i class="fa fa-users"></i> <span><?php echo e(trans('message.extra_text.customers')); ?></span>
          </a>
        </li>
        
        <li <?= $menu == 'plots' ? ' class="active"' : ''?> >
          <a href="<?php echo e(url('plots/list')); ?>">
            <i class="fa fa-inbox"></i> <span><?php echo e(trans('message.extra_text.plots')); ?></span>
          </a>
        </li>

        <li <?= $menu == 'item' ? ' class="active"' : ''?> >
          <a href="<?php echo e(url('item')); ?>">
            <i class="fa fa-cubes"></i>
            <span><?php echo e(trans('message.sidebar.item')); ?></span>
          </a>
        </li>
        
        <li <?= $menu == 'sales' ? ' class="treeview active"' : 'treeview'?> >
          <a href="#">
            <i class="fa fa-list-ul"></i>
            <span><?php echo e(trans('message.sidebar.sales')); ?></span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?= isset($sub_menu) && $sub_menu == 'order/list' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('order/list')); ?>">
                <span><?php echo e(trans('message.table.sales_order_no')); ?></span>
              </a>
            </li>
            <li <?= isset($sub_menu) && $sub_menu == 'sales/direct-invoice' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('sales/list')); ?>">
                
                <span><?php echo e(trans('message.table.invoices')); ?></span>
              </a>
            </li>  
            <li <?= isset($sub_menu) && $sub_menu == 'payment/list' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('payment/list')); ?>">
                
                <span><?php echo e(trans('message.extra_text.payments')); ?></span>
              </a>
            </li>
            <li <?= isset($sub_menu) && $sub_menu == 'shipment/list' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('shipment/list')); ?>">
              
                <span><?php echo e(trans('message.customer_panel.shipments')); ?></span>
              </a>
            </li> 
          </ul>
        </li>

        <li <?= $menu == 'supplier' ? ' class="active"' : ''?> >
          <a href="<?php echo e(url('supplier')); ?>">
            <i class="fa fa-users"></i> <span><?php echo e(trans('message.extra_text.supplier')); ?></span>
          </a>
        </li>

        <li <?= $menu == 'purchase' ? ' class="active"' : ''?> >
          <a href="<?php echo e(url('purchase/list')); ?>">
            <i class="fa fa-shopping-cart"></i> <span><?php echo e(trans('message.extra_text.purchases')); ?></span>
          </a>
        </li>

        <li <?= $menu == 'transfer' ? ' class="active"' : ''?> >
          <a href="<?php echo e(url('transfer/list')); ?>">
            <i class="fa fa-truck"></i> <span><?php echo e(trans('message.sidebar.stock-move-list')); ?></span>
          </a>
        </li>

        <li <?= $menu == 'report' ? ' class="treeview active"' : 'treeview'?> >
          <a href="#">
            <i class="fa fa-bar-chart"></i>
            <span><?php echo e(trans('message.sidebar.report')); ?></span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            
            <li <?= isset($sub_menu) && $sub_menu == 'report/inventory-stock-on-hand' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('report/inventory-stock-on-hand')); ?>">
                
                <span><?php echo e(trans('message.sidebar.inventory_stock_on_hand')); ?></span>
              </a>
            </li>

            <li <?=isset($sub_menu) && $sub_menu == 'report/sales-report' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('report/sales-report')); ?>">
                
                <span><?php echo e(trans('message.sidebar.sales_report')); ?></span>
              </a>
            </li>

            <li <?=isset($sub_menu) && $sub_menu == 'sales-history-report' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('report/sales-history-report')); ?>">
                
                <span><?php echo e(trans('message.sidebar.sales_history_report')); ?></span>
              </a>
            </li>
            
            <li <?=isset($sub_menu) && $sub_menu == 'report/purchases-order-report' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('report/purchases-order-report')); ?>">
                
                <span><?php echo e(trans('message.sidebar.purchases_order_report')); ?></span>
              </a>
            </li>
            
          </ul>
        </li>
        <li <?= $menu == 'setting' ? ' class="treeview active"' : 'treeview'?> >
          <a href="#">
            <i class="fa fa-gears"></i>
            <span><?php echo e(trans('message.form.settings')); ?></span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?=isset($sub_menu) && $sub_menu == 'company' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('company/setting')); ?>">
                <span><?php echo e(trans('message.table.company_details')); ?></span>
              </a>
            </li>

            <li <?= isset($sub_menu) && $sub_menu == 'general' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('item-category')); ?>">
                <span><?php echo e(trans('message.table.general_settings')); ?></span>
              </a>
            </li>
            
            <li <?=isset($sub_menu) && $sub_menu == 'finance' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('tax')); ?>">
                <span><?php echo e(trans('message.table.finance')); ?></span>
              </a>
            </li>

            <?php if(!empty(Session::get('emailtemp'))): ?>
            <li <?=isset($sub_menu) && $sub_menu == 'mail-temp' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('customer-invoice-temp/1')); ?>">
                <span><?php echo e(trans('message.email.email_template')); ?></span>
              </a>
            </li>
            <?php endif; ?>

            <?php if(!empty(Session::get('preference'))): ?>
            <li <?=isset($sub_menu) && $sub_menu == 'preference' ? ' class="active"' : ''?> >
              <a href="<?php echo e(url('setting-preference')); ?>">
                <span><?php echo e(trans('message.table.preference')); ?></span>
              </a>
            </li>
            <?php endif; ?>

          </ul>
        </li>
     
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>