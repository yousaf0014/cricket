<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
                <h4><?php echo e(trans('message.customer_panel.my_payment')); ?></h4>
            </div>
        </div>

      <!-- Default box -->
        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th><?php echo e(trans('message.invoice.payment_no')); ?></th>
                    <th><?php echo e(trans('message.table.order_no')); ?></th>
                    <th><?php echo e(trans('message.invoice.invoice_no')); ?></th>
                    
                    <th><?php echo e(trans('message.invoice.payment_on')); ?></th>
                    <th><?php echo e(trans('message.invoice.amount')); ?>(<?php echo e($currency->symbol); ?>)</th>
                    <th><?php echo e(trans('message.invoice.payment_date')); ?></th>

                  </tr>
                  </thead>
                  <tbody>
                  <?php foreach($paymentList as $data): ?>
                  <tr>
                    <td><a href="<?php echo e(url("customer-panel/view-receipt/$data->id")); ?>"><?php echo e(sprintf("%04d", $data->id)); ?></a></td>
                    <td><a href="<?php echo e(url("customer-panel/view-order-details/$data->order_id")); ?>"><?php echo e($data->order_reference); ?></a></td>
                    <td><a href="<?php echo e(url("customer-panel/view-detail-invoice/$data->order_id/$data->invoice_id")); ?>"><?php echo e($data->invoice_reference); ?></a></td>
                   
                    <td><?php echo e($data->pay_type); ?></td>
                    <td><?php echo e(number_format($data->amount,2,'.',',')); ?></td>
                    <td><?php echo e(formatDate($data->payment_date)); ?></td>
                    
                  </tr>
                 <?php endforeach; ?>
                  </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        
        <!-- /.box-footer-->
    

    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

    $(function () {
      
      
      $("#example1").DataTable({
        "order": []
      });
      
    });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>