
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">
          <?php echo $__env->make('layouts.includes.sub_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
            <div class="col-md-6">
             <div class="top-bar-title padding-bottom"><?php echo e(trans('message.table.category')); ?></div>
            </div> 

           <?php if(!empty($access['cat_add'])): ?>
            <div class="col-md-3 top-left-btn">
                <a href="<?php echo e(URL::to('categoryimport')); ?>" class="btn btn-block btn-default btn-flat btn-border-purple"><span class="fa fa-upload"> &nbsp;</span><?php echo e(trans('message.extra_text.import_new_categry')); ?></a>
            </div>

            <div class="col-md-3 top-right-btn">
                <a href="javascript:void(0)" data-toggle="modal" data-target="#add-category" class="btn btn-block btn-default btn-flat btn-border-orange"><?php echo e(trans('message.table.add_new_category')); ?></a>
            </div>
            <?php endif; ?>

          </div>
        </div>
      </div>

          <div class="box">
            <div class="box-header">
              <a href="<?php echo e(URL::to('categorydownloadExcel/csv')); ?>"><button class="btn btn-default btn-flat btn-border-info"><span class="fa fa-download"> &nbsp;</span><?php echo e(trans('message.table.downolad_csv')); ?></button></a>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th><?php echo e(trans('message.table.category')); ?></th>
                  <th><?php echo e(trans('message.table.unit')); ?></th>
                  <th width="5%"><?php echo e(trans('message.table.action')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($categoryData as $data): ?>
                <tr>
                  <td><a class="edit_category" id="<?php echo e($data->category_id); ?>" href="javascript:void(0)"><?php echo e($data->description); ?></a></td>
                  <td><?php echo e($data->name); ?></td>
                  <td>
                  <?php if(!empty($access['cat_edit'])): ?>

                      <a title="<?php echo e(trans('message.form.edit')); ?>" href="javascript:void(0)" class="btn btn-xs btn-primary edit_category" id="<?php echo e($data->category_id); ?>"><span class="fa fa-edit"></span></a> &nbsp;
                  <?php endif; ?>

                  <?php if(!empty($access['cat_delete'])): ?>
                    <?php if(!in_array($data->category_id,[1])): ?>
                      <form method="POST" action="<?php echo e(url("delete-category/$data->category_id")); ?>" accept-charset="UTF-8" style="display:inline">
                          <?php echo csrf_field(); ?>

                          <button title="<?php echo e(trans('message.form.Delete')); ?>" class="btn btn-xs btn-danger" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.table.delete_category_header')); ?>" data-message="<?php echo e(trans('message.table.delete_category')); ?>">
                              <i class="glyphicon glyphicon-trash"></i> 
                          </button>
                      </form>
                      <?php endif; ?>
                  <?php endif; ?>
                  </td>
                </tr>
               <?php endforeach; ?>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

    </section>

<div id="add-category" class="modal fade" role="dialog" style="display: none;">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title"><?php echo e(trans('message.table.add_new')); ?></h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(url('save-category')); ?>" method="post" id="myform1" class="form-horizontal">
            <?php echo csrf_field(); ?>

          
          <div class="form-group">
            <label class="col-sm-3 control-label require" for="inputEmail3"><?php echo e(trans('message.form.category')); ?></label>

            <div class="col-sm-6">
              <input type="text" placeholder="Name" class="form-control" name="description">
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label require" for="inputEmail3"><?php echo e(trans('message.form.unit')); ?></label>

            <div class="col-sm-6">
              <select class="form-control valdation_select" name="dflt_units" >
              <option value=""><?php echo e(trans('message.form.select_one')); ?></option>
              <?php foreach($unitData as $data): ?>
                <option value="<?php echo e($data->id); ?>" ><?php echo e($data->name); ?></option>
              <?php endforeach; ?>
              </select>
            </div>
          </div>

          
          <div class="form-group">
            <label for="btn_save" class="col-sm-3 control-label"></label>
            <div class="col-sm-6">
              <button type="button" class="btn btn-info btn-flat" data-dismiss="modal"><?php echo e(trans('message.form.close')); ?></button>
              <button type="submit" class="btn btn-primary btn-flat"><?php echo e(trans('message.form.submit')); ?></button>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>


<div id="edit-category" class="modal fade" role="dialog" style="display: none;">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Add New</h4>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(url('update-category')); ?>" method="post" id="editCat" class="form-horizontal">
            <?php echo csrf_field(); ?>

          
          <div class="form-group">
            <label class="col-sm-3 control-label require" for="inputEmail3"><?php echo e(trans('message.form.category')); ?></label>

            <div class="col-sm-6">
              <input type="text" placeholder="Name" class="form-control" id="name" name="description">
              <span id="val_name" style="color: red"></span>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label require" for="inputEmail3"><?php echo e(trans('message.form.unit')); ?></label>

            <div class="col-sm-6">
              <select class="form-control" name="dflt_units" id="dflt_units">
              
              <?php foreach($unitData as $data): ?>
                <option value="<?php echo e($data->id); ?>" ><?php echo e($data->name); ?></option>
              <?php endforeach; ?>
              </select>
            </div>
          </div>
          <input type="hidden" name="cat_id" id="cat_id">

          <?php if(!empty($access['cat_edit'])): ?>
          <div class="form-group">
            <label for="btn_save" class="col-sm-3 control-label"></label>
            <div class="col-sm-6">
              <button type="button" class="btn btn-info btn-flat" data-dismiss="modal"><?php echo e(trans('message.form.close')); ?></button>
              <button type="submit" class="btn btn-primary btn-flat"><?php echo e(trans('message.form.submit')); ?></button>
            </div>
          </div>
          <?php endif; ?>
          
        </form>
      </div>
    </div>

  </div>
</div>
    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
      $(function () {
        $("#example1").DataTable({
          "columnDefs": [ {
            "targets": 2,
            "orderable": false
            } ],

            "language": '<?php echo e(Session::get('dflt_lang')); ?>',
        "pageLength": '<?php echo e(Session::get('row_per_page')); ?>'
            //"pageLength": 5
        });
        
      });


      $('.edit_category').on('click', function() {
        var id = $(this).attr("id");

        $.ajax({
            url: '<?php echo e(URL::to('edit-category')); ?>',
            data:{  // data that will be sent
                id:id
            },
            type: 'POST',
            dataType: 'JSON',
            success: function (data) {
              
                $('#name').val(data.name);
                $('#dflt_units').val(data.dflt_units);
                $('#cat_id').val(data.category_id);

                $('#edit-category').modal();
            }
        });

    });

      $('#myform1').validate({
        rules: {
            description: {
                required: true
            },
            dflt_units: {
                required: true
            }                     
        }
    });

    $('#editCat').validate({
        rules: {
            description: {
                required: true
            },
            dflt_units: {
                required: true
            }                     
        }
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>