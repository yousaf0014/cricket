<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <!---Top Section Start-->
      <div class="box box-default">
        <div class="box-body">
          <div class="row">
            <div class="col-md-10">
             <div class="top-bar-title"><?php echo e(trans('message.extra_text.sales_order')); ?></div>
            </div>
            <div class="col-md-2">
              <?php if(!empty(Session::get('order_add'))): ?>
                <a href="<?php echo e(url("order/add")); ?>" class="btn btn-block btn-default btn-flat btn-border-orange"><?php echo e(trans('message.extra_text.new_sales_order')); ?></a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
      <!---Top Section End-->
    <div class="row">
        <div class="col-md-8 right-padding-col8">
            <div class="box box-default">
              <div class="box-body">
                
                  <div class="row">
                    <div class="col-md-4">
                      <strong><?php echo e(trans('message.invoice.order_date')); ?> : <?php echo e(formatDate($saleData->ord_date)); ?></strong>
                      <br>
                      <strong><?php echo e(trans('message.extra_text.location')); ?> : <?php echo e($saleData->location_name); ?></strong>
                    </div>
                    <div class="col-md-8">
                      <div class="btn-group pull-right">
                        <button title="Email" type="button" class="btn btn-default btn-flat" data-toggle="modal" data-target="#emailOrder"><?php echo e(trans('message.extra_text.email')); ?></button>
                        <a target="_blank" href="<?php echo e(URL::to('/')); ?>/order/print/<?php echo e($saleData->order_no); ?>" title="Print" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.print')); ?></a>
                        <a target="_blank" href="<?php echo e(URL::to('/')); ?>/order/pdf/<?php echo e($saleData->order_no); ?>" title="PDF" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.pdf')); ?></a>
                        <?php if(!empty(Session::get('order_edit'))): ?>
                          <a href="<?php echo e(URL::to('/')); ?>/order/edit/<?php echo e($saleData->order_no); ?>" title="Edit" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.edit')); ?></a>
                        <?php endif; ?>

                        <?php if(!empty(Session::get('order_delete'))): ?>
                         <form method="POST" action="<?php echo e(url("order/delete/$saleData->order_no")); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo csrf_field(); ?>

                            <button class="btn btn-default btn-flat delete-btn" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.invoice.delete_order')); ?>" data-message="<?php echo e(trans('message.invoice.delete_order_confirm')); ?>">
                               <?php echo e(trans('message.extra_text.delete')); ?>

                            </button>
                        </form>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
              </div>

              <div class="box-body">
                <div class="row">
                  
                  <div class="col-md-4">
                    <strong><?php echo e(Session::get('company_name')); ?></strong>
                    <h5 class=""><?php echo e(Session::get('company_street')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_city')); ?>, <?php echo e(Session::get('company_state')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_country_id')); ?>, <?php echo e(Session::get('company_zipCode')); ?></h5>
                  </div>

                  <div class="col-md-4">
                  <strong><?php echo e(trans('message.extra_text.bill_to')); ?></strong>
                  <h5><?php echo e(!empty($customerInfo->name) ? $customerInfo->name : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->billing_street) ? $customerInfo->billing_street : ''); ?> </h5>
                  <h5><?php echo e(!empty($customerInfo->billing_state) ? $customerInfo->billing_state : ''); ?><?php echo e(!empty($customerInfo->billing_city) ? ', '.$customerInfo->billing_city : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->billing_country_id) ? $customerInfo->billing_country_id : ''); ?> <?php echo e(!empty($customerInfo->billing_zip_code) ? ', '.$customerInfo->billing_zip_code : ''); ?></h5>
                  </div>
                  
                  <div class="col-md-4">
                  <strong><?php echo e(trans('message.extra_text.shiptment_to')); ?></strong>
                  <h5><?php echo e(!empty($customerInfo->br_name) ? $customerInfo->br_name : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_street) ? $customerInfo->shipping_street :''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_city) ? $customerInfo->shipping_city : ''); ?> <?php echo e(!empty($customerInfo->shipping_state) ? ', '.$customerInfo->shipping_state : ''); ?></h5>
                  <h5><?php echo e(!empty($customerInfo->shipping_country_id) ? $customerInfo->shipping_country_id :''); ?> <?php echo e(!empty($customerInfo->shipping_zip_code) ? ', '.$customerInfo->shipping_zip_code : ''); ?></h5>
                  </div>

                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="box-body no-padding">
                      <div class="table-responsive">
                      <table class="table table-bordered" id="salesInvoice">
                        <tbody>
                        <tr class="tbl_header_color dynamicRows">
                          <th width="30%" class="text-center"><?php echo e(trans('message.table.description')); ?></th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.quantity')); ?></th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.rate')); ?>(<?php echo e(Session::get('currency_symbol')); ?>)</th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.tax')); ?>(%)</th>
                           <th class="text-center" width="10%"><?php echo e(trans('message.table.discount')); ?>(%)</th>
                          <th width="10%" class="text-center"><?php echo e(trans('message.table.amount')); ?>(<?php echo e(Session::get('currency_symbol')); ?>)</th>
                        </tr>
                        <?php if(count($invoiceData)>0): ?>
                         <?php $subTotal = 0;$units = 0;$itemsInformation = '';?>
                          <?php foreach($invoiceData as $result): ?>
                              <tr>
                                <td class="text-center"><?php echo e($result['description']); ?></td>
                                <td class="text-center"><?php echo e($result['quantity']); ?></td>
                                <td class="text-center"><?php echo e(number_format($result['unit_price'],2,'.',',')); ?></td>
                                <td class="text-center"><?php echo e(number_format($result['tax_rate'],2,'.',',')); ?></td>
                                <td class="text-center"><?php echo e(number_format($result['discount_percent'],2,'.',',')); ?></td>
                                <?php
                                  $priceAmount = ($result['quantity']*$result['unit_price']);
                                  $discount = ($priceAmount*$result['discount_percent'])/100;
                                  $newPrice = ($priceAmount-$discount);
                                  $subTotal += $newPrice;
                                  $units += $result['quantity'];
                                  $itemsInformation .= '<div>'.$result['quantity'].'x'.' '.$result['description'].'</div>';
                                ?>
                                <td align="right"><?php echo e(number_format($newPrice,2,'.',',')); ?></td>
                              </tr>
                          <?php endforeach; ?>
                          <tr class="tableInfos"><td colspan="5" align="right"><?php echo e(trans('message.table.total_qty')); ?></td><td align="right" colspan="2"><?php echo e($units); ?></td></tr>
                        <tr class="tableInfos"><td colspan="5" align="right"><?php echo e(trans('message.table.sub_total')); ?></td><td align="right" colspan="2"><?php echo e(Session::get('currency_symbol').number_format($subTotal,2,'.',',')); ?></td></tr>
                        <?php foreach($taxType as $rate=>$tax_amount): ?>
                        <?php if($rate != 0): ?>
                        <tr><td colspan="5" align="right">Plus Tax(<?php echo e($rate); ?>%)</td><td colspan="2" class="text-right"><?php echo e(Session::get('currency_symbol').number_format($tax_amount,2,'.',',')); ?></td></tr>
                        <?php endif; ?>
                        <?php endforeach; ?>
                          <tr class="tableInfos"><td colspan="5" align="right"><strong><?php echo e(trans('message.table.grand_total')); ?></strong></td><td colspan="2" class="text-right"><strong><?php echo e(Session::get('currency_symbol').number_format($saleData->total,2,'.',',')); ?></strong></td></tr>
                          <?php
                           $invoiceAmount = 0;
                            if(!empty($paymentsList)){
                             
                              foreach ($paymentsList as $key => $paymentAmount) {
                               $invoiceAmount += $paymentAmount->amount;
                              }
                            }
                          ?>
                          <tr><td colspan="5" align="right"><?php echo e(trans('message.invoice.paid')); ?></td><td colspan="2" class="text-right"><?php echo e(Session::get('currency_symbol').number_format($invoiceAmount,2,'.',',')); ?></td></tr>
                          <tr class="tableInfos"><td colspan="5" align="right"><strong><?php echo e(trans('message.invoice.due')); ?></strong></td><td colspan="2" class="text-right"><strong><?php echo e(Session::get('currency_symbol').number_format(($saleData->total-$invoiceAmount),2,'.',',')); ?></strong></td></tr>
                        <?php endif; ?>
                        </tbody>
                      </table>
                      </div>
                      <br><br>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      <!--Modal start-->
        <div id="emailOrder" class="modal fade" role="dialog">
          <div class="modal-dialog">
            <form id="sendOrderInfo" method="POST" action="<?php echo e(url('order/email-order-info')); ?>">
            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">
            <input type="hidden" value="<?php echo e($orderInfo->order_no); ?>" name="order_id" id="order_id">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><?php echo e(trans('message.email.email_order_info')); ?></h4>
              </div>
              <div class="modal-body">
                <div class="form-group">
                  <label for="email"><?php echo e(trans('message.email.send_to')); ?>:</label>
                  <input type="email" value="<?php echo e($customerInfo->email); ?>" class="form-control" name="email" id="email">
                </div>
                <?php
                $subjectInfo = str_replace('{order_reference_no}', $orderInfo->reference, $emailInfo->subject);
                $subjectInfo = str_replace('{company_name}', Session::get('company_name'), $subjectInfo);
                ?>
                <div class="form-group">
                  <label for="subject"><?php echo e(trans('message.email.subject')); ?>:</label>
                  <input type="text" class="form-control" name="subject" id="subject" value="<?php echo e($subjectInfo); ?>">
                </div>
                  <div class="form-groupa">
                      <?php
                      $bodyInfo = str_replace('{customer_name}', $customerInfo->name, $emailInfo->body);
                      $bodyInfo = str_replace('{order_reference_no}', $orderInfo->reference, $bodyInfo);
                      $bodyInfo = str_replace('{billing_street}', $customerInfo->billing_street, $bodyInfo);
                      $bodyInfo = str_replace('{billing_city}', $customerInfo->billing_city, $bodyInfo);
                      $bodyInfo = str_replace('{billing_state}', $customerInfo->billing_state, $bodyInfo);
                      $bodyInfo = str_replace('{billing_zip_code}', $customerInfo->billing_zip_code, $bodyInfo);
                      $bodyInfo = str_replace('{billing_country}', $customerInfo->billing_country_id, $bodyInfo);                      
                      $bodyInfo = str_replace('{company_name}', Session::get('company_name'), $bodyInfo);
                      $bodyInfo = str_replace('{order_summery}', $itemsInformation, $bodyInfo);                     
                      $bodyInfo = str_replace('{currency}', Session::get('currency_symbol'), $bodyInfo);
                      $bodyInfo = str_replace('{total_amount}', $saleData->total, $bodyInfo); 
                      $bodyInfo = str_replace('{order_date}', formatDate($saleData->ord_date), $bodyInfo); 
                      ?>
                      <textarea id="compose-textarea" name="message" id='message' class="form-control editor" style="height: 200px"><?php echo e($bodyInfo); ?></textarea>
                  </div>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm" data-dismiss="modal"><?php echo e(trans('message.email.close')); ?></button><button type="submit" class="btn btn-primary btn-sm"><?php echo e(trans('message.email.send')); ?></button>
              </div>
            </div>
            </form>
          </div>
        </div>
        <!--Modal end -->
         <?php echo $__env->make('layouts.includes.content_right_option', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </section>
<?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

      $(function () {
        $(".editor").wysihtml5();
      });

    $('#sendOrderInfo').validate({
        rules: {
            email: {
                required: true
            },
            subject:{
               required: true,
            },
            message:{
               required: true,
            }                   
        }
    }); 

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>