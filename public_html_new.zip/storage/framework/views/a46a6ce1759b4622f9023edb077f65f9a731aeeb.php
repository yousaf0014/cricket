<!-- Profile Image -->
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo e(trans('message.header.general_setting')); ?></h3>
  </div>
  <div class="box-body no-padding" style="display: block;">
    <ul class="nav nav-pills nav-stacked">
      
      <li <?php echo e(isset($list_menu) &&  $list_menu == 'category' ? 'class=active' : ''); ?> ><a href="<?php echo e(URL::to("item-category")); ?>"><?php echo e(trans('message.sidebar.item_category')); ?></a></li>
      <li <?php echo e(isset($list_menu) &&  $list_menu == 'unit' ? 'class=active' : ''); ?> ><a href="<?php echo e(URL::to("unit")); ?>"><?php echo e(trans('message.extra_text.units')); ?></a></li>

      <li <?php echo e(isset($list_menu) &&  $list_menu == 'backup' ? 'class=active' : ''); ?>><a href="<?php echo e(URL::to("backup/list")); ?>"><?php echo e(trans('message.extra_text.db_backup')); ?></a></li>
      <?php if(!empty(Session::get('email_add'))): ?>
      <li <?php echo e(isset($list_menu) &&  $list_menu == 'email_setup' ? 'class=active' : ''); ?>><a href="<?php echo e(URL::to("email/setup")); ?>"><?php echo e(trans('message.extra_text.email_setup')); ?></a></li>
      <?php endif; ?>
      
      
    </ul>
  </div>
  <!-- /.box-body -->
</div>