
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
    <div class="row">
        <?php foreach($itemData as $data): ?>
        <div class="col-lg-3 col-xs-6">
            <!-- small box -->
            <div class="small-box bg-aqua">
                <div class="inner">
                    <h3><?php echo e($data->purchase_price); ?></h3>
                    <p><?php echo e($data->description); ?></p>
                </div>
                <div class="icon">
                    <?php if(!empty($data->img)): ?>
                    <img src='<?php echo e(url("public/uploads/itemPic/$data->img")); ?>' alt="" width="50" height="50">
                    <?php else: ?>
                    <img src='<?php echo e(url("public/uploads/default-image.png")); ?>' alt="" width="50" height="50">
                    <?php endif; ?>
                </div>
                <a href="<?php echo e(route('customer.order.cart', ['id' => $data->item_id ])); ?>" class="small-box-footer">Add To Cart <i class="fa fa-arrow-circle-right"></i></a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>