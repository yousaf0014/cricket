
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

      <div class="box box-default">
        <div class="box-body">
          <div class="row">
            <div class="col-md-8">
             <div class="top-bar-title padding-bottom"><?php echo e(trans('message.extra_text.item')); ?></div>
            </div> 
             <?php if(!empty(Session::get('item_add'))): ?>
            <div class="col-md-2 top-left-btn">
                <a href="<?php echo e(URL::to('itemimport')); ?>" class="btn btn-block btn-default btn-flat btn-border-purple"><span class="fa fa-upload"> &nbsp;</span><?php echo e(trans('message.extra_text.import_new_item')); ?></a>
            </div>

            <div class="col-md-2 top-right-btn">
                <a href="<?php echo e(url('create-item/item')); ?>" class="btn btn-block btn-default btn-flat btn-border-orange"><?php echo e(trans('message.extra_text.add_new_item')); ?></a>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

      <!-- Top Box-->
      <div class="box">
        <div class="box-body">
          <div class="col-md-2 col-xs-6 border-right text-center">
              <h3 class="bold"><?php echo e(count($itemData)); ?></h3>
              <span class="text-info bold"><?php echo e(trans('message.table.item')); ?></span>
          </div>
          <div class="col-md-2 col-xs-6 border-right text-center">
              <h3 class="bold"><?php echo e(!empty($itemQuantity->total_item) ? $itemQuantity->total_item : 0); ?></h3>
              <span class="text-info bold"><?php echo e(trans('message.extra_text.quantity')); ?></span>
          </div>


          <div class="col-md-3 col-xs-6 border-right text-center">
              <h3 class="bold"><?php echo e(Session::get('currency_symbol').number_format($costValueQtyOnHand,2,'.',',')); ?></h3>
              <span class="text-info"><?php echo e(trans('message.report.on_hand_cost_value')); ?></span>
          </div>
          <div class="col-md-3 col-xs-6 border-right text-center">
              <h3 class="bold"><?php echo e(Session::get('currency_symbol').number_format($retailValueOnHand ,2,'.',',')); ?></h3>
              <span class="text-info"><?php echo e(trans('message.report.on_hand_retail_value')); ?> </span>
          </div>
          <div class="col-md-2 col-xs-6 text-center">
              <h3 class="bold"><?php echo e(Session::get('currency_symbol').number_format($profitValueOnHand,2,'.',',')); ?></h3>
              <span class="text-info"><?php echo e(trans('message.report.on_hand_profit_value')); ?></span>
          </div>


        </div>
        <br>
      </div><!--Top Box End-->

      <!-- Default box -->
      <div class="box">
      
            <div class="box-header">
              <a href="<?php echo e(URL::to('plotdownloadcsv/csv')); ?>"><button class="btn btn-default btn-flat btn-border-info"><span class="fa fa-download"> &nbsp;</span><?php echo e(trans('message.table.download_csv')); ?></button></a>
            </div>
  
            <!-- /.box-header -->
            <div class="box-body">
              <table id="itemList" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th class="text-center"><?php echo e(trans('message.table.picture')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.table.name')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.table.category')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.table.on_hand')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.table.purchase')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.table.wholesale')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.table.retail')); ?></th>
                  <th class="text-center"><?php echo e(trans('message.form.status')); ?></th>
                  <th width="14%" class="text-center"><?php echo e(trans('message.table.action')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($itemData as $data): ?>
                <tr>
                  <td width="5%" class="text-center">
                  <a href="<?php echo e(url("edit-item/item-info/$data->item_id")); ?>">
                    <?php if(!empty($data->img)): ?>
                    <img src='<?php echo e(url("public/uploads/itemPic/$data->img")); ?>' alt="" width="50" height="50">
                    <?php else: ?>
                    <img src='<?php echo e(url("public/uploads/default-image.png")); ?>' alt="" width="50" height="50">
                    <?php endif; ?>
                    </a>
                  </td>
                  <td class="text-center"><a href="<?php echo e(url("edit-item/item-info/$data->item_id")); ?>"><?php echo e($data->description); ?></a></td>
                  <td class="text-center"><?php echo e($data->category_name); ?></td>
                  <td class="text-center"><?php echo e($data->item_qty); ?></td>
                  <td class="text-center"><?php echo e($data->purchase_price); ?></td>
                  <td class="text-center"><?php echo e($data->whole_sale_price); ?></td>
                  <td class="text-center"><?php echo e($data->retail_sale_price); ?></td>
                  <td class="text-center">
                  <?php if($data->inactive == 0): ?>
                    <span class='label label-success'>Active</span>
                  <?php else: ?>
                    <span class='label label-danger'>Inactive</span>
                  <?php endif; ?>
                  </td>
                  
                  <td class="text-center">
                  <?php if(!empty(Session::get('item_edit'))): ?>
                      <a title="edit" class="btn btn-xs btn-primary" href='<?php echo e(url("edit-item/item-info/$data->item_id")); ?>'><span class="fa fa-edit"></span></a> &nbsp;
                  <?php endif; ?>
                  <?php if(!empty(Session::get('item_delete'))): ?>
                      <form method="POST" action="<?php echo e(url("item/delete/$data->item_id")); ?>" accept-charset="UTF-8" style="display:inline">
                          <?php echo csrf_field(); ?>

                          <button title="<?php echo e(trans('message.form.Delete')); ?>" class="btn btn-xs btn-danger" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.table.delete_item_header')); ?>" data-message="<?php echo e(trans('message.table.delete_item')); ?>">
                              <i class="glyphicon glyphicon-trash"></i> 
                          </button> &nbsp;
                      </form>
                  <?php endif; ?>
                  </td>
                </tr>
               <?php endforeach; ?>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
      <!-- /.box -->

    </section>

<?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

  $(function () {
    $("#itemList").DataTable({
      "order": [],

      "columnDefs": [ {
        "targets": 8,
        "orderable": false
        } ],

        "language": '<?php echo e(Session::get('dflt_lang')); ?>',
        "pageLength": '<?php echo e(Session::get('row_per_page')); ?>'
    });
    
  });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>