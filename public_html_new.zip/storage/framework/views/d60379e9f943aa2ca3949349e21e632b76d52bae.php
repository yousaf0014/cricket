
<?php $__env->startSection('content'); ?>
<!-- Main content -->
<section class="content">
    <!-- Default box -->
    <div class="row">
        <div class="col-md-12">
            <div class="box box-default">
                <!-- /.box-header -->
                <div class="box-body">
                    <form action="<?php echo e(url('customer-panel/order/saveCart')); ?>" method="POST" id="salesForm">  
                        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">

                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputEmail1"><?php echo e(trans('message.extra_text.payment_method')); ?></label>
                                    <select class="form-control select2" name="payment_id">

                                        <?php foreach($payments as $payment): ?>
                                        <option value="<?php echo e($payment->id); ?>" <?= ($payment->defaults == "1" ? 'selected' : '') ?>><?php echo e($payment->name); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                        </div>        
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Quantity</label>
                                    <input class="form-control text-center no_units valid" min="0" data-id="4" data-rate="925" id="qty_4" name="item_quantity" value="1" aria-invalid="false" type="text">
                                </div>
                            </div>

                        </div>        
                        <div class="row">
                            <div class="col-lg-3 col-xs-6">
                                <!-- small box -->
                                <div class="small-box bg-aqua">
                                    <div class="inner">
                                        <h3><?php echo e($itemData->purchase_price); ?></h3>
                                        <p><?php echo e($itemData->description); ?></p>
                                    </div>
                                    <div class="icon">
                                        <?php if(!empty($itemData->img)): ?>
                                        <img src='<?php echo e(url("public/uploads/itemPic/$itemData->img")); ?>' alt="" width="50" height="50">
                                        <?php else: ?>
                                        <img src='<?php echo e(url("public/uploads/default-image.png")); ?>' alt="" width="50" height="50">
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <!-- /.box-body -->
                            <input type="hidden" name="item_id" value="<?php echo e($itemData->item_id); ?>">
                            <input type="hidden" name="unit_price" value="<?php echo e($itemData->retail_sale_price); ?>">
                            <input type="hidden" name="stock_id" value="<?php echo e($itemData->stock_id); ?>">
                            <input type="hidden" name="description" value="<?php echo e($itemData->description); ?>">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="exampleInputEmail1"><?php echo e(trans('message.table.note')); ?></label>
                                    <textarea placeholder="<?php echo e(trans('message.table.description')); ?> ..." rows="3" class="form-control" name="comments"></textarea>
                                </div>
                                <a href="<?php echo e(url('/customer-panel/order/add')); ?>" class="btn btn-info btn-flat"><?php echo e(trans('message.form.cancel')); ?></a>
                                <button type="submit" class="btn btn-primary btn-flat pull-right" id="btnSubmit"><?php echo e(trans('message.form.submit')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- /.row -->
            </div>
            </section>
            <?php $__env->stopSection(); ?>
            <?php $__env->startSection('js'); ?>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>