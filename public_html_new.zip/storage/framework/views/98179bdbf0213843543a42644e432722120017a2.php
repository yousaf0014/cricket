<?php $__env->startSection('content'); ?>
  <section class="content">

    <div class="box box-default">
      <div class="box-body">
        <div class="row">
          <div class="col-md-10">
           <div class="top-bar-title padding-bottom"><?php echo e(trans('message.extra_text.purchase')); ?></div>
          </div> 
          <div class="col-md-2">
            <?php if(!empty(Session::get('purchese_add'))): ?>
              <a href="<?php echo e(url('purchase/add')); ?>" class="btn btn-block btn-default btn-flat btn-border-orange"><?php echo e(trans('message.extra_text.new_purchase')); ?></a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">
          <div class="box box-default">
          <div class="box-body">
                <div class="btn-group pull-right">
                  <a target="_blank" href="<?php echo e(URL::to('/')); ?>/purchase/print/<?php echo e($purchData->order_no); ?>" title="Print" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.print')); ?></a>
                  <a target="_blank" href="<?php echo e(URL::to('/')); ?>/purchase/pdf/<?php echo e($purchData->order_no); ?>" title="PDF" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.pdf')); ?></a>
                   <?php if(!empty(Session::get('purchese_edit'))): ?>
                  <a href="<?php echo e(URL::to('/')); ?>/purchase/edit/<?php echo e($purchData->order_no); ?>" title="Edit" class="btn btn-default btn-flat"><?php echo e(trans('message.extra_text.edit')); ?></a>
                    <?php endif; ?>
                    <?php if(!empty(Session::get('purchese_delete'))): ?>
                  <form method="POST" action="<?php echo e(url("purchase/delete/$purchData->order_no")); ?>" accept-charset="UTF-8" style="display:inline">
                      <?php echo csrf_field(); ?>

                      <button class="btn btn-default btn-flat delete-btn" title="<?php echo e(trans('message.table.delete')); ?>" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.invoice.delete_purchase')); ?>" data-message="<?php echo e(trans('message.invoice.delete_purchase_confirm')); ?>">
                         <?php echo e(trans('message.extra_text.delete')); ?>

                      </button>
                  </form>
                    <?php endif; ?>
                </div>
          </div>

            <div class="box-body">
              <div class="row">
                
                  <div class="col-md-4">
                    <strong><?php echo e(Session::get('company_name')); ?></strong>
                    <h5 class=""><?php echo e(Session::get('company_street')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_city')); ?>, <?php echo e(Session::get('company_state')); ?></h5>
                    <h5 class=""><?php echo e(Session::get('company_country_id')); ?>, <?php echo e(Session::get('company_zipCode')); ?></h5>
                  </div>

                <div class="col-md-4">
                  <strong><?php echo e(!empty($purchData->supp_name) ? $purchData->supp_name : ''); ?></strong>
                  <h5><?php echo e(!empty($purchData->address) ? $purchData->address : ''); ?></h5>
                  <h5><?php echo e(!empty($purchData->city) ? $purchData->city : ''); ?><?php echo e(!empty($purchData->state) ? ', '.$purchData->state : ''); ?></h5>
                  <h5><?php echo e(!empty($purchData->country) ? $purchData->country : ''); ?><?php echo e(!empty($purchData->zipcode) ? ', '.$purchData->zipcode : ''); ?></h5>
                </div>

                <div class="col-md-4">
                    <strong><?php echo e(trans('message.table.invoice_no').' # '.$purchData->reference); ?></strong>
                    <h5><?php echo e(trans('message.extra_text.location')); ?> : <?php echo e($purchData->location_name); ?></h5>
                    <h5><?php echo e(trans('message.table.date')); ?> : <?php echo e(formatDate($purchData->ord_date)); ?></h5>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="box-body no-padding">
                    <div class="table-responsive">
                    <table class="table table-bordered" id="salesInvoice">
                      <tbody>
                      <tr class="tbl_header_color dynamicRows">
                        <th width="30%" class="text-center"><?php echo e(trans('message.table.description')); ?></th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.quantity')); ?></th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.rate')); ?>(<?php echo e(Session::get('currency_symbol')); ?>)</th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.tax')); ?>(%)</th>
                        <th width="10%" class="text-center"><?php echo e(trans('message.table.amount')); ?></th>
                      </tr>
                      <?php
                       $itemsInformation = '';
                      ?>
                      <?php if(count($invoiceItems)>0): ?>
                       <?php $subTotal = 0;$units = 0;?>
                        <?php foreach($invoiceItems as $result): ?>
                            <tr>
                              <td class="text-center"><?php echo e($result->description); ?></td>
                              <td class="text-center"><?php echo e($result->quantity_received); ?></td>
                              <td class="text-center"><?php echo e(number_format($result->unit_price,2,'.',',')); ?></td>
                              <td class="text-center"><?php echo e($result->tax_rate); ?></td>
                              <?php
                                $priceAmount = ($result->quantity_received*$result->unit_price);
                                $subTotal += $priceAmount;
                                $units += $result->quantity_received;
                                $itemsInformation .= '<div>'.$result->quantity_received.'x'.' '.$result->description.'</div>';
                              ?>
                              <td align="right"><?php echo e(Session::get('currency_symbol').number_format($priceAmount,2,'.',',')); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="tableInfos"><td colspan="4" align="right"><?php echo e(trans('message.table.total_qty')); ?></td><td align="right" colspan="2"><?php echo e($units); ?></td></tr>
                      <tr class="tableInfos"><td colspan="4" align="right"><?php echo e(trans('message.table.sub_total')); ?></td><td align="right" colspan="2"><?php echo e(Session::get('currency_symbol').number_format($subTotal,2,'.',',')); ?></td></tr>
                      <?php foreach($taxType as $rate=>$tax_amount): ?>
                      <?php if($rate != 0): ?>
                      <tr><td colspan="4" align="right">Plus Tax(<?php echo e($rate); ?>%)</td><td colspan="2" class="text-right"><?php echo e(Session::get('currency_symbol').number_format($tax_amount,2,'.',',')); ?></td></tr>
                      <?php endif; ?>
                      <?php endforeach; ?>
                      <tr class="tableInfos"><td colspan="4" align="right"><strong><?php echo e(trans('message.table.grand_total')); ?></strong></td><td colspan="2" class="text-right"><strong><?php echo e(Session::get('currency_symbol').number_format($purchData->total,2,'.',',')); ?></strong></td></tr>
                      <?php endif; ?>
                      </tbody>
                    </table>
                    </div>
                    <br><br>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
      </div>
  </section>
  <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>