
Click here to reset your password: <a href="<?php echo e($link = url('password/resets',$data['token'])); ?>"> <?php echo e($link); ?> </a>
