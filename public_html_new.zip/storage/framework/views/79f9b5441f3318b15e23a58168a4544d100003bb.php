<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
                <h4><?php echo e(trans('message.customer_panel.my_branch')); ?></h4>
            </div>
        </div>
      <!-- Default box -->
        <div class="box">
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr>
                      
                      <th><?php echo e(trans('message.customer_panel.branch_name')); ?></th>
                      <th><?php echo e(trans('message.customer_panel.contact')); ?></th>
                      <th width="15%" class="text-center"><?php echo e(trans('message.customer_panel.action')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                  <?php if(!empty($cusBranchData)): ?>
                  
                  <?php foreach($cusBranchData as $data): ?>
                    <tr>
                      <td><?php echo e($data->br_name); ?></td>
                      <td><?php echo e($data->br_contact); ?></td>
                      
                      <td class="text-center">

                        <a class="btn btn-xs btn-info" href='<?php echo e(url("customer-panel/branch/edit/$data->branch_code")); ?>'><span class="fa fa-edit"></span></a>
                      </td>
                    </tr>
                   <?php endforeach; ?>
                   <?php endif; ?>
                    </tfoot>
                  </table>
            </div>
            <!-- /.box-body -->
          </div>
        <!-- /.box-footer-->
    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">

    $(function () {
      
      $("#example1").DataTable({
        "order": []
      });
      
    });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>