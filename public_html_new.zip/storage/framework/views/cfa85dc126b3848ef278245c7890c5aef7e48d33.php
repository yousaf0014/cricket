<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <!--Default box -->
        <div class="box">
           <div class="panel-body">
                <ul class="nav nav-tabs cus" role="tablist">
                    
                    <li>
                      <a href='<?php echo e(url("customer/edit/$customerData->debtor_no")); ?>' ><?php echo e(trans('message.sidebar.profile')); ?></a>
                    </li>
                    
                    <li class="active">
                      <a href="<?php echo e(url("customer/order/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.sales_orders')); ?></a>
                    </li>
                    <li>
                      <a href="<?php echo e(url("customer/invoice/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.invoices')); ?></a>
                    </li>
                    <li>
                      <a href="<?php echo e(url("customer/payment/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.payments')); ?></a>
                    </li>
                    <li>
                      <a href="<?php echo e(url("customer/shipment/$customerData->debtor_no")); ?>" ><?php echo e(trans('message.extra_text.deliveries')); ?></a>
                    </li>
               </ul>
              <div class="clearfix"></div>
           </div>
        </div> 
        <h3><?php echo e($customerData->name); ?></h3> 
        
        <div class="box">
      
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th><?php echo e(trans('message.table.order')); ?> #</th>
                    <th><?php echo e(trans('message.invoice.ordered')); ?></th>
                    <th><?php echo e(trans('message.invoice.invoiced')); ?></th>
                    <th><?php echo e(trans('message.invoice.packed')); ?></th>
                    <th><?php echo e(trans('message.invoice.paid')); ?></th>
                    <th><?php echo e(trans('message.invoice.total')); ?></th>
                    <th><?php echo e(trans('message.table.ord_date')); ?></th>
                    <th width="11%"><?php echo e(trans('message.table.action')); ?></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach($salesOrderData as $data): ?>
                <tr>
                  <td><a href="<?php echo e(URL::to('/')); ?>/order/view-order-details/<?php echo e($data->order_no); ?>"><?php echo e($data->reference); ?></a></td>
                  <td><?php echo e($data->ordered_quantity); ?></td>

                    <?php if( $data->invoiced_quantity == 0 ): ?>
                    <td><span class="fa fa-circle-thin"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->invoiced_quantity)== 0): ?>
                    <td><span class="fa fa-circle"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->invoiced_quantity)>0): ?>
                    <td><span class="glyphicon glyphicon-adjust"></span></td>
                    <?php endif; ?>


                    <?php if( $data->packed_qty == 0 ): ?>
                    <td><span class="fa fa-circle-thin"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->packed_qty)== 0): ?>
                    <td><span class="fa fa-circle"></span></td>
                    <?php elseif(abs($data->ordered_quantity) - abs($data->packed_qty)>0): ?>
                    <td><span class="glyphicon glyphicon-adjust"></span></td>
                    <?php endif; ?>

                    <?php if( $data->paid_amount == 0 ): ?>
                    <td><span class="fa fa-circle-thin"></span></td>
                    <?php elseif(abs($data->order_amount) - abs($data->paid_amount)== 0): ?>
                    <td><span class="fa fa-circle"></span></td>
                    <?php elseif(abs($data->order_amount) - abs($data->paid_amount)>0): ?>
                    <td><span class="glyphicon glyphicon-adjust"></span></td>
                    <?php endif; ?>

                    <td><?php echo e(Session::get('currency_symbol').number_format($data->order_amount,2,'.',',')); ?></td>
                    <td><?php echo e(formatDate($data->ord_date)); ?></td>

                  
                  <td class="text-center">
                    <?php if(!empty(Session::get('order_edit'))): ?>
                        <a title="View" class="btn btn-xs btn-primary" href=<?php echo e(url("order/view-order-details/$data->order_no")); ?>><span class="fa fa-eye"></span></a> &nbsp;
                        <a  title="Edit" class="btn btn-xs btn-info" href='<?php echo e(url("order/edit/$data->order_no")); ?>'><span class="fa fa-edit"></span></a> &nbsp;
                    <?php endif; ?>

                    <?php if(!empty(Session::get('order_delete'))): ?>
                        <form method="POST" action="<?php echo e(url("customer/delete-sales-info")); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="action_name" value="delete_order">
                            <input type="hidden" name="order_no" value="<?php echo e($data->order_no); ?>">
                            <input type="hidden" name="customer_id" value="<?php echo e($customerData->debtor_no); ?>">
                            <button title="delete" class="btn btn-xs btn-danger" type="button" data-toggle="modal" data-target="#confirmDelete" data-title="<?php echo e(trans('message.invoice.delete_order')); ?>" data-message="<?php echo e(trans('message.invoice.delete_order_confirm')); ?>">
                                <i class="glyphicon glyphicon-trash"></i> 
                            </button>
                        </form>
                    <?php endif; ?>       
              
                  </td>
                </tr>
               <?php endforeach; ?>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
        <!-- /.box-footer-->
    <?php echo $__env->make('layouts.includes.message_boxes', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript">
    $(function () {
      $("#example1").DataTable({
        "order": [],
        "columnDefs": [ {
          "targets": 4,
          "orderable": false
          } ],

          "language": '<?php echo e(Session::get('dflt_lang')); ?>',
          "pageLength": '<?php echo e(Session::get('row_per_page')); ?>'
      });
      
    });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>